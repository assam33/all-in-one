import Image from "next/image";
import markWhite from "@/assets/logo-mark-white.png";
import { heroFacts } from "@/data/site";
import { btnGhost, btnPrimary, cn } from "@/lib/ui";
import Container from "./Container";

export default function Hero() {
  return (
    <section id="home" className="bg-paper pb-16 pt-12 lg:pb-22 lg:pt-18">
      <Container className="grid gap-12 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)] lg:items-stretch lg:gap-18">
        <div>
          <h1 className="max-w-[18ch] text-[clamp(2.5rem,5.4vw,4.25rem)] font-bold leading-[1.04] tracking-[-0.035em] motion-safe:animate-rise lg:max-w-[14ch]">
            Software that helps your business run better.
          </h1>
          <p className="mt-6 max-w-136 text-[1.2rem] leading-[1.6] motion-safe:animate-rise-2">
            DevFox designs and builds websites, mobile apps and custom software for companies in Pakistan and
            around the world.
          </p>
          <div className="mt-9 flex flex-wrap gap-[0.85rem] motion-safe:animate-rise-3">
            <a href="#contact" className={cn(btnPrimary, "max-sm:flex-[1_1_100%]")}>
              Start a project
            </a>
            <a href="#work" className={cn(btnGhost, "max-sm:flex-[1_1_100%]")}>
              See our work
            </a>
          </div>
          <dl className="mt-10 flex flex-wrap gap-x-8 gap-y-5 border-t border-line pt-7 motion-safe:animate-rise-4 sm:mt-14 sm:gap-x-12">
            {heroFacts.map((fact) => (
              <div key={fact.label}>
                <dt className="text-[0.9rem] text-muted">{fact.label}</dt>
                <dd className="font-head text-[1.1rem] font-semibold text-ink">{fact.value}</dd>
              </div>
            ))}
          </dl>
        </div>

        {/* The one bold element on the page */}
        <aside
          aria-label="DevFox"
          className="relative isolate flex min-h-[380px] flex-col justify-between overflow-hidden rounded-[22px] bg-[linear-gradient(155deg,#2D6CF6_0%,#5A4DF0_50%,#9440E8_100%)] p-6 text-white motion-safe:animate-rise-visual sm:min-h-[460px] sm:rounded-[28px] sm:p-8 lg:min-h-130"
        >
          <Image
            src={markWhite}
            alt=""
            priority
            className="absolute left-1/2 top-[46%] -z-10 h-auto w-[58%] max-w-68 -translate-x-1/2 -translate-y-1/2"
          />
          <p className="inline-flex items-center gap-[0.6rem] self-start rounded-full bg-white/16 px-[0.95rem] py-[0.45rem] text-[0.92rem] font-semibold">
            <span className="size-2 rounded-full bg-[#5EEAA0]" aria-hidden="true" />
            Open for new projects
          </p>
          <p className="max-w-76 font-head text-[1.2rem] sm:max-w-120 lg:max-w-76 font-semibold leading-[1.25] tracking-[-0.02em] sm:text-[1.45rem]">
            Engineers and designers working side by side with you, from the first sketch to launch day.
          </p>
        </aside>
      </Container>
    </section>
  );
}
