import { projects, type ProjectTone } from "@/data/site";
import { h2, sectionPad } from "@/lib/ui";
import Container from "./Container";
import { ProjectIcon } from "./icons";

const tones: Record<ProjectTone, string> = {
  blue: "bg-[#DCE7FF] text-[#2349A8]",
  teal: "bg-[#D5F0EA] text-[#176B5A]",
  violet: "bg-[#E8DEFC] text-[#5B2DB0]",
  slate: "bg-[#DDE1EE] text-[#2F3A66]",
};

export default function Work() {
  return (
    <section id="work" className={`bg-paper ${sectionPad}`}>
      <Container>
        <div className="mb-10 max-w-152 lg:mb-14">
          <h2 className={h2}>Selected work</h2>
          <p className="mt-4 text-[1.1rem]">
            The kinds of products we build, across finance, healthcare, education and logistics.
          </p>
        </div>

        <div className="grid gap-x-8 gap-y-12 sm:grid-cols-2">
          {projects.map((project) => (
            <article key={project.title}>
              <div
                className={`relative grid h-[210px] place-items-center overflow-hidden rounded-[20px] sm:h-[250px] ${tones[project.tone]}`}
              >
                <span className="absolute left-4 top-4 rounded-full bg-white/85 px-[0.85rem] py-[0.3rem] text-[0.88rem] font-semibold text-ink">
                  {project.sector}
                </span>
                <ProjectIcon name={project.icon} className="size-21" />
              </div>
              <h3 className="mt-5 text-[1.4rem] font-semibold">{project.title}</h3>
              <p className="mt-2">{project.text}</p>
              <p className="mt-[0.85rem] border-t border-line pt-[0.85rem] text-[0.95rem] text-muted">
                {project.stack}
              </p>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}
