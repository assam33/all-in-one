import Image from "next/image";
import { team } from "@/data/site";
import { h2, sectionPad } from "@/lib/ui";
import Container from "./Container";
import SocialLinks from "./SocialLinks";

export default function Team() {
  return (
    <section id="team" className={sectionPad}>
      <Container>
        <div className="mb-10 max-w-152 lg:mb-14">
          <h2 className={h2}>The people behind DevFox</h2>
          <p className="mt-4 text-[1.1rem]">
            You will speak to the founders directly, from your first message to the final handover.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {team.map((member) => (
            <article
              key={member.name}
              className="grid items-start gap-5 sm:grid-cols-[240px_minmax(0,1fr)] sm:gap-7"
            >
              <Image
                src={member.photo}
                alt={member.alt}
                sizes="(max-width: 640px) 320px, 240px"
                className="aspect-[4/5] h-auto w-full rounded-[20px] bg-paper object-cover object-[50%_22%] max-sm:max-w-[320px]"
              />
              <div>
                <h3 className="text-2xl font-[650]">{member.name}</h3>
                <p className="mt-[0.15rem] font-semibold text-brand">{member.role}</p>
                <p className="mt-[0.9rem] text-base">{member.bio}</p>
                <SocialLinks links={member.social} who={member.name} />
              </div>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}
