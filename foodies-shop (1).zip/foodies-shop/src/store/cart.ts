"use client";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartLine, Product } from "@/types";
import { MAX_QTY } from "@/lib/schemas";

type CartState = {
  lines: CartLine[];
  lastRemoved: CartLine | null; // enables "Undo" (memory only, not persisted)
  add: (p: Product, qty?: number) => void;
  setQty: (slug: string, qty: number) => void;
  remove: (slug: string) => void;
  undo: () => void;
  clear: () => void;
};

let undoTimer: ReturnType<typeof setTimeout> | undefined;
const clamp = (n: number) => Math.min(MAX_QTY, Math.max(1, n));

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      lastRemoved: null,
      add: (p, qty = 1) =>
        set((s) => {
          const found = s.lines.find((l) => l.slug === p.slug);
          if (found) return { lastRemoved: null, lines: s.lines.map((l) => (l.slug === p.slug ? { ...l, qty: clamp(l.qty + qty) } : l)) };
          return { lastRemoved: null, lines: [...s.lines, { slug: p.slug, name: p.name, price: p.price, image: p.image, qty: clamp(qty) }] };
        }),
      setQty: (slug, qty) => set((s) => ({ lines: s.lines.map((l) => (l.slug === slug ? { ...l, qty: clamp(qty) } : l)) })),
      remove: (slug) => {
        const line = get().lines.find((l) => l.slug === slug);
        if (!line) return;
        set((s) => ({ lines: s.lines.filter((l) => l.slug !== slug), lastRemoved: line }));
        clearTimeout(undoTimer);
        undoTimer = setTimeout(() => set({ lastRemoved: null }), 6000);
      },
      undo: () => {
        const line = get().lastRemoved;
        if (line) set((s) => ({ lines: [...s.lines, line], lastRemoved: null }));
      },
      clear: () => set({ lines: [], lastRemoved: null }),
    }),
    { name: "foodies-cart", partialize: (s) => ({ lines: s.lines }) },
  ),
);
