"use client";
import { create } from "zustand";
import { useSyncExternalStore } from "react";

type UIState = {
  cartOpen: boolean;
  menuOpen: boolean;
  searchOpen: boolean;
  set: (v: Partial<Omit<UIState, "set">>) => void;
};

export const useUI = create<UIState>((set) => ({
  cartOpen: false,
  menuOpen: false,
  searchOpen: false,
  set: (v) => set(v),
}));

/** false during SSR + hydration, true afterwards (avoids localStorage hydration mismatches). */
export const useMounted = () =>
  useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );
