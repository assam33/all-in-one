"use client";
import { useMemo } from "react";
import { useCatalog } from "@/components/CatalogProvider";
import { site } from "@/data/site";
import { MAX_QTY } from "@/lib/schemas";
import type { CartLine } from "@/types";
import { useCart } from "./cart";
import { useMounted } from "./ui";

export type CartViewLine = CartLine & { max: number; unavailable: boolean; overStock: boolean };

/**
 * One place that turns the stored cart into what the UI shows.
 * Names/prices/stock always come from the current catalogue, so a stale price saved in the
 * browser can never be displayed (the server recalculates and checks stock at checkout anyway).
 */
export function useCartView() {
  const mounted = useMounted();
  const stored = useCart((s) => s.lines);
  const { products } = useCatalog();

  return useMemo(() => {
    const lines: CartViewLine[] = (mounted ? stored : []).map((l) => {
      const p = products[l.slug];
      if (!p) return { ...l, max: 0, unavailable: true, overStock: false };
      const max = Math.min(MAX_QTY, p.stock ?? MAX_QTY);
      return { ...l, name: p.name, price: p.price, image: p.image, max, unavailable: max < 1, overStock: max >= 1 && l.qty > max };
    });
    const subtotal = lines.filter((l) => !l.unavailable).reduce((n, l) => n + l.price * l.qty, 0);
    const deliveryFee = lines.length ? site.deliveryFee : 0;
    const blocked = lines.some((l) => l.unavailable || l.overStock);
    const belowMin = lines.length > 0 && subtotal < site.minOrder;
    return {
      mounted,
      lines,
      count: lines.reduce((n, l) => n + l.qty, 0),
      subtotal,
      deliveryFee,
      total: subtotal + deliveryFee,
      blocked,
      belowMin,
      cannotCheckout: blocked || belowMin,
      shortBy: Math.max(0, site.minOrder - subtotal),
    };
  }, [mounted, stored, products]);
}
