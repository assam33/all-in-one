import type { Metadata } from "next";
import CartPage from "@/components/cart/CartPage";

export const metadata: Metadata = { title: "Your cart" };

export default function Page() {
  return (
    <div className="mx-auto max-w-[1100px] px-4 pb-8">
      <h1 className="pb-8 pt-12 text-center text-3xl md:text-4xl">Your cart</h1>
      <CartPage />
    </div>
  );
}
