import type { Metadata } from "next";
import AdminLogin from "@/components/admin/AdminLogin";
import AdminNav from "@/components/admin/AdminNav";
import { adminConfigured, isAdminSession } from "@/lib/admin";

export const metadata: Metadata = { robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  if (!(await isAdminSession())) return <AdminLogin configured={adminConfigured()} />;
  return (
    <>
      <AdminNav />
      <div className="mx-auto max-w-[1100px] px-4 pb-8">{children}</div>
    </>
  );
}
