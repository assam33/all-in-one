import type { Metadata } from "next";
import CategoriesAdmin from "@/components/admin/CategoriesAdmin";

export const metadata: Metadata = { title: "Categories" };

export default function Page() {
  return (
    <>
      <h1 className="pb-8 pt-10 text-3xl">Categories</h1>
      <CategoriesAdmin />
    </>
  );
}
