import type { Metadata } from "next";
import MediaAdmin from "@/components/admin/MediaAdmin";

export const metadata: Metadata = { title: "Images & Video" };

export default function Page() {
  return (
    <>
      <h1 className="pb-8 pt-10 text-3xl">Images & Video</h1>
      <MediaAdmin />
    </>
  );
}
