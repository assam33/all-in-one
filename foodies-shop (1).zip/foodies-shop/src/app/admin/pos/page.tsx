import type { Metadata } from "next";
import PosAdmin from "@/components/admin/PosAdmin";

export const metadata: Metadata = { title: "POS & Inventory" };

export default function Page() {
  return (
    <>
      <h1 className="pb-8 pt-10 text-3xl">POS & Inventory</h1>
      <PosAdmin />
    </>
  );
}
