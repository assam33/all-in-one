import type { Metadata } from "next";
import ProductsAdmin from "@/components/admin/ProductsAdmin";

export const metadata: Metadata = { title: "Products" };

export default function Page() {
  return (
    <>
      <h1 className="pb-8 pt-10 text-3xl">Products</h1>
      <ProductsAdmin />
    </>
  );
}
