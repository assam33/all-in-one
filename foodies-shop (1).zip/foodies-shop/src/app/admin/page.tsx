import type { Metadata } from "next";
import AdminOrders from "@/components/admin/AdminOrders";

export const metadata: Metadata = { title: "Orders" };

export default function Page() {
  return (
    <>
      <h1 className="pb-8 pt-10 text-3xl">Orders</h1>
      <AdminOrders />
    </>
  );
}
