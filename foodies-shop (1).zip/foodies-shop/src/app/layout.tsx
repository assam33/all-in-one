import type { Metadata } from "next";
import "./globals.css";
import { site } from "@/data/site";
import { getCatalogProducts, getCategoryTree } from "@/lib/catalog";
import CatalogProvider from "@/components/CatalogProvider";
import TopBar from "@/components/layout/TopBar";
import Header from "@/components/layout/Header";
import CategoryNav from "@/components/layout/CategoryNav";
import MobileMenu from "@/components/layout/MobileMenu";
import Footer from "@/components/layout/Footer";
import CartDrawer from "@/components/cart/CartDrawer";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"),
  title: { default: site.name, template: `%s | ${site.name}` },
  description: site.description,
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const [categories, products] = await Promise.all([getCategoryTree(), getCatalogProducts()]);
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        <CatalogProvider categories={categories} products={products}>
          <TopBar />
          <Header />
          <CategoryNav categories={categories} />
          <main className="min-h-[50vh]">{children}</main>
          <Footer />
          <CartDrawer />
          <MobileMenu />
        </CatalogProvider>
      </body>
    </html>
  );
}
