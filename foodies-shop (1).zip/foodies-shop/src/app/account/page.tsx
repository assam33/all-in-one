import type { Metadata } from "next";
import TrackOrderForm from "@/components/checkout/TrackOrderForm";

export const metadata: Metadata = { title: "Account" };

export default function AccountPage() {
  return (
    <div className="mx-auto max-w-[600px] px-4 pb-8">
      <h1 className="pb-8 pt-12 text-center text-3xl md:text-4xl">Track your order</h1>
      <TrackOrderForm />
      <p className="mt-8 text-center text-sm text-white/60">Customer login and order history are coming soon.</p>
    </div>
  );
}
