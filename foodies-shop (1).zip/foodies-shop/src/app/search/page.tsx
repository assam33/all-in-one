import type { Metadata } from "next";
import { searchProducts } from "@/lib/catalog";
import ProductGrid from "@/components/product/ProductGrid";

export const metadata: Metadata = { title: "Search" };

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string | string[] }> }) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q : "";
  const results = await searchProducts(q);

  return (
    <div className="mx-auto max-w-[1366px] px-4 pb-8">
      <h1 className="pb-8 pt-12 text-center text-3xl md:text-4xl">{q ? `Results for “${q}”` : "Search"}</h1>
      {results.length > 0 ? (
        <ProductGrid products={results} />
      ) : (
        <p className="py-16 text-center text-white/70">{q ? "No items matched your search." : "Use the search icon to find your favourite food."}</p>
      )}
    </div>
  );
}
