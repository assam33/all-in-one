import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getOrder } from "@/lib/orders";
import { cardProvider } from "@/lib/payments/server";
import { formatPrice } from "@/lib/format";
import MockGateway from "@/components/order/MockGateway";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Test payment", robots: { index: false } };

// Stand-in for a real gateway page while developing. Disabled automatically in production.
export default async function MockPayPage({ params }: { params: Promise<{ id: string }> }) {
  if (cardProvider() !== "mock") notFound();
  const order = await getOrder((await params).id);
  if (!order || order.paymentMethod !== "card") notFound();

  return (
    <div className="mx-auto max-w-[480px] px-4 py-16 text-center">
      <p className="mb-4 inline-block rounded bg-amber-400 px-3 py-1 text-sm font-bold text-black">TEST MODE — no real money is charged</p>
      <h1 className="text-3xl">Card payment</h1>
      <p className="mt-3 text-white/70">Order {order.id}</p>
      <p className="mb-8 text-3xl">{formatPrice(order.total)}</p>
      <MockGateway orderId={order.id} />
    </div>
  );
}
