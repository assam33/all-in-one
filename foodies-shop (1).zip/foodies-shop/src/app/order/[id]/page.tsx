import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CheckCircle2, Clock, XCircle } from "lucide-react";
import type { Order } from "@/types";
import { site } from "@/data/site";
import { formatPrice } from "@/lib/format";
import { getOrder } from "@/lib/orders";
import { methodInfo, paymentStatusLabel } from "@/lib/payments/methods";
import { verifyCardPayment } from "@/lib/payments/server";
import { RetryCardButton, TransferForm } from "@/components/order/PaymentActions";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order status", robots: { index: false } };

function PaymentPanel({ order }: { order: Order }) {
  const box = "mt-6 rounded-md border border-white/15 bg-panel p-5";
  const failed = order.paymentStatus === "failed";

  if (order.status === "cancelled") return null;
  if (order.paymentStatus === "paid") return <div className={box}><p>✅ Payment received. Thank you!</p></div>;

  if (order.paymentMethod === "cod") {
    return <div className={box}><p>Please keep <strong>{formatPrice(order.total)}</strong> in cash ready for the delivery person.</p></div>;
  }

  if (order.paymentMethod === "card") {
    return (
      <div className={box}>
        <p>{failed ? "Your card payment was not completed." : "Your order will be confirmed as soon as the card payment is completed."}</p>
        <RetryCardButton orderId={order.id} failed={failed} />
      </div>
    );
  }

  // transfer
  if (order.paymentStatus === "awaiting_verification") {
    return (
      <div className={box}>
        <p>We received your transaction ID <strong>{order.paymentRef}</strong>. Our team will verify the payment and confirm your order shortly.</p>
      </div>
    );
  }
  return (
    <div className={box}>
      {failed && <p className="mb-3 rounded-md bg-red-500/15 px-3 py-2 text-red-300">We could not verify your last transaction ID. Please check it and submit again.</p>}
      <h2 className="mb-1 text-lg">Send {formatPrice(order.total)} to one of these accounts</h2>
      <p className="mb-4 text-sm text-white/60">Write your order ID <strong className="text-white">{order.id}</strong> in the payment note if possible.</p>
      <ul className="space-y-3">
        {site.payments.transfer.accounts.map((a) => (
          <li key={a.name} className="rounded-md bg-ink px-4 py-3 text-sm">
            <p className="font-bold">{a.name}{a.bank ? ` — ${a.bank}` : ""}</p>
            <p>{a.title}</p>
            <p className="text-base tracking-wide">{a.number}</p>
          </li>
        ))}
      </ul>
      <TransferForm orderId={order.id} />
    </div>
  );
}

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const found = await getOrder((await params).id);
  if (!found) notFound();
  const order = await verifyCardPayment(found);

  const cancelled = order.status === "cancelled";
  const pending = order.status === "pending_payment";
  const Icon = cancelled ? XCircle : pending ? Clock : CheckCircle2;
  const iconColor = cancelled ? "text-red-500" : pending ? "text-amber-400" : "text-green-500";

  return (
    <div className="mx-auto max-w-[700px] px-4 pb-8 pt-12">
      <div className="mb-8 text-center">
        <Icon className={`mx-auto mb-3 size-14 ${iconColor}`} />
        <h1 className="text-3xl">{cancelled ? "Order cancelled" : pending ? "Complete your payment" : "Order received"}</h1>
        <p className="mt-2 text-white/70">
          {cancelled ? "This order was cancelled. Please contact us if you need help." : pending ? `Thank you, ${order.customer.name}. Your order is reserved until payment is completed.` : `Thank you, ${order.customer.name}. We will contact you shortly to confirm.`}
        </p>
      </div>

      <div className="rounded-md bg-panel p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-4 text-sm">
          <span>Order ID: <strong className="text-base">{order.id}</strong></span>
          <span className="text-white/70">{new Date(order.createdAt).toLocaleString("en-GB")}</span>
          <span className="rounded-full bg-white/15 px-3 text-xs uppercase leading-6">{paymentStatusLabel(order)}</span>
        </div>
        <ul className="space-y-2 text-sm">
          {order.items.map((i) => (
            <li key={i.slug} className="flex justify-between"><span>{i.name} × {i.qty}</span><span>{formatPrice(i.price * i.qty)}</span></li>
          ))}
        </ul>
        <dl className="mt-4 space-y-1 border-t border-white/10 pt-4 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatPrice(order.subtotal)}</dd></div>
          <div className="flex justify-between"><dt>Delivery</dt><dd>{order.deliveryFee ? formatPrice(order.deliveryFee) : "Free"}</dd></div>
          <div className="flex justify-between text-lg"><dt>Total</dt><dd>{formatPrice(order.total)}</dd></div>
          <div className="flex justify-between text-white/60"><dt>Payment method</dt><dd>{methodInfo[order.paymentMethod].label}</dd></div>
        </dl>
      </div>

      <PaymentPanel order={order} />

      <div className="mt-8 text-center">
        <Link href="/" className="rounded-md bg-brand px-6 py-2.5 font-bold">CONTINUE SHOPPING</Link>
      </div>
    </div>
  );
}
