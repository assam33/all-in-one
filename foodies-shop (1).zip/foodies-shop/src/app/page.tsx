import HeroSlider from "@/components/home/HeroSlider";
import VideoBanner from "@/components/home/VideoBanner";
import ProductSection from "@/components/product/ProductSection";
import { getCatalog, getProductsIn } from "@/lib/catalog";

// Home sections are driven by category slugs below; hero slides + promo video come from /admin/media.
export default async function Home() {
  const [{ media }, starters, burgers, deli] = await Promise.all([getCatalog(), getProductsIn("starters"), getProductsIn("burgers"), getProductsIn("pizza", "sandwich")]);
  return (
    <>
      <HeroSlider slides={media.heroSlides} />
      <ProductSection title="Starters" size="lg" products={starters} href="/category/starters" />
      <ProductSection title="Burgers" products={burgers} href="/category/burgers" />
      <VideoBanner promo={media.promo} />
      <div className="pt-4">
        <ProductSection title="Freshly baked, just for you" products={deli} href="/category/deli" />
      </div>
    </>
  );
}
