import Link from "next/link";

export default function NotFound() {
  return (
    <div className="py-24 text-center">
      <h1 className="text-5xl text-brand">404</h1>
      <p className="mb-8 mt-3 text-white/70">Sorry, we couldn&apos;t find that page.</p>
      <Link href="/" className="rounded-md bg-brand px-6 py-2.5 font-bold">BACK TO HOME</Link>
    </div>
  );
}
