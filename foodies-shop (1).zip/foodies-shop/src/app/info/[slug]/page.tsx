import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { infoPages, site } from "@/data/site";

type Props = { params: Promise<{ slug: string }> };

export const dynamicParams = false;
export const generateStaticParams = () => Object.keys(infoPages).map((slug) => ({ slug }));

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  return { title: infoPages[(await params).slug]?.title ?? "Info" };
}

export default async function InfoPage({ params }: Props) {
  const { slug } = await params;
  const page = infoPages[slug];
  if (!page) notFound();
  const showContact = ["contact", "careers", "franchise"].includes(slug);

  return (
    <div className="mx-auto max-w-[800px] px-4 pb-8">
      <h1 className="pb-8 pt-12 text-center text-3xl md:text-4xl">{page.title}</h1>
      <div className="space-y-4 text-white/80">{page.body.map((p) => <p key={p}>{p}</p>)}</div>
      {showContact && (
        <ul className="mt-8 space-y-2 rounded-md bg-panel p-5">
          <li>Phone: <a href={`tel:${site.contact.supportPhone}`} className="hover:text-brand">{site.contact.supportPhone}</a></li>
          <li>UAN: {site.contact.uan}</li>
          <li>Email: <a href={`mailto:${site.contact.email}`} className="hover:text-brand">{site.contact.email}</a></li>
        </ul>
      )}
    </div>
  );
}
