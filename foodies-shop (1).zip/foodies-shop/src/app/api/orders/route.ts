import { NextResponse } from "next/server";
import { createOrder, OrderError } from "@/lib/orders";
import { availableMethods, startCardPayment } from "@/lib/payments/server";
import { orderSchema } from "@/lib/schemas";

export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const parsed = orderSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid order" }, { status: 400 });
  }
  if (!availableMethods().includes(parsed.data.method)) {
    return NextResponse.json({ error: "This payment method is not available." }, { status: 400 });
  }

  try {
    const order = await createOrder(parsed.data);
    if (order.paymentMethod === "card") {
      try {
        return NextResponse.json({ id: order.id, redirectUrl: await startCardPayment(order) }, { status: 201 });
      } catch (err) {
        console.error("Card payment could not be started:", err);
        return NextResponse.json({ id: order.id, paymentError: "We could not start the card payment. You can retry from your order page." }, { status: 201 });
      }
    }
    return NextResponse.json({ id: order.id }, { status: 201 });
  } catch (err) {
    if (err instanceof OrderError) return NextResponse.json({ error: err.message }, { status: err.status });
    console.error("Order failed:", err);
    return NextResponse.json({ error: "Could not place your order. Please try again." }, { status: 500 });
  }
}
