import { NextResponse } from "next/server";
import { getOrder } from "@/lib/orders";
import { startCardPayment } from "@/lib/payments/server";

// Retry a card payment for an existing unpaid order.
export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const order = await getOrder((await params).id);
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  if (order.paymentMethod !== "card" || order.paymentStatus === "paid" || order.status === "cancelled") {
    return NextResponse.json({ error: "This order cannot be paid by card." }, { status: 400 });
  }
  try {
    return NextResponse.json({ redirectUrl: await startCardPayment(order) });
  } catch (err) {
    console.error("Card retry failed:", err);
    return NextResponse.json({ error: "Could not start the payment. Please try again." }, { status: 502 });
  }
}
