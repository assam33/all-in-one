import { NextResponse } from "next/server";
import { getOrder, OrderError, updateOrder } from "@/lib/orders";
import { transferSchema } from "@/lib/schemas";

// Customer submits the transaction ID of their bank / wallet transfer.
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const parsed = transferSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });

  const order = await getOrder((await params).id);
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  if (order.paymentMethod !== "transfer" || order.paymentStatus === "paid" || order.status === "cancelled") {
    return NextResponse.json({ error: "Payment details cannot be submitted for this order." }, { status: 400 });
  }
  try {
    await updateOrder(order.id, (o) => ({ ...o, paymentRef: parsed.data.reference, paymentStatus: "awaiting_verification" }));
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof OrderError) return NextResponse.json({ error: err.message }, { status: err.status });
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}
