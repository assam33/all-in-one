import { NextResponse } from "next/server";
import { markFailed, markPaid } from "@/lib/orders";
import { verifyStripeSignature } from "@/lib/payments/server";

// Configure in Stripe: endpoint /api/payments/stripe/webhook, events checkout.session.completed + checkout.session.expired
export async function POST(req: Request) {
  const raw = await req.text(); // raw body is required for signature verification
  if (!verifyStripeSignature(raw, req.headers.get("stripe-signature") ?? "")) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }
  const event = JSON.parse(raw);
  const session = event.data?.object;
  const orderId: string | undefined = session?.metadata?.orderId ?? session?.client_reference_id;
  try {
    if (orderId && event.type === "checkout.session.completed" && session.payment_status === "paid") await markPaid(orderId, session.id);
    else if (orderId && event.type === "checkout.session.expired") await markFailed(orderId);
  } catch (err) {
    console.error("Webhook handling failed:", err); // still reply 200 so Stripe doesn't retry unknown orders forever
  }
  return NextResponse.json({ received: true });
}
