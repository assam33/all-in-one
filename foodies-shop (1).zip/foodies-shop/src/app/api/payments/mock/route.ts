import { NextResponse } from "next/server";
import { getOrder, markFailed, markPaid } from "@/lib/orders";
import { cardProvider } from "@/lib/payments/server";

// TEST gateway only: lets you simulate a successful / failed card payment without real money.
export async function POST(req: Request) {
  if (cardProvider() !== "mock") return NextResponse.json({ error: "Not found" }, { status: 404 });
  const { orderId, result } = (await req.json().catch(() => ({}))) as { orderId?: string; result?: string };
  const order = orderId ? await getOrder(orderId) : undefined;
  if (!order || order.paymentMethod !== "card") return NextResponse.json({ error: "Order not found" }, { status: 404 });

  if (result === "success") await markPaid(order.id, `mock_${Date.now()}`);
  else await markFailed(order.id);
  return NextResponse.json({ ok: true });
}
