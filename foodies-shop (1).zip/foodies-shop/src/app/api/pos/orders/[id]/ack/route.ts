import { updateOrder } from "@/lib/orders";
import { posGuard } from "@/lib/pos";

// POS confirms it has imported the order, so it is not returned by GET /api/pos/orders again.
export const POST = (req: Request, { params }: { params: Promise<{ id: string }> }) =>
  posGuard(req, async () => {
    const order = await updateOrder((await params).id, (o) => ({
      ...o,
      posSync: { status: "sent", attempts: o.posSync?.attempts ?? 0, at: new Date().toISOString(), acked: true },
    }));
    return { ok: true, id: order.id };
  });
