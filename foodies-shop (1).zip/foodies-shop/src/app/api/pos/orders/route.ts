import { listOrders } from "@/lib/orders";
import { posGuard } from "@/lib/pos";

// POS pulls confirmed orders it has not acknowledged yet (add ?all=1 to include acknowledged ones).
export const GET = (req: Request) =>
  posGuard(req, async () => {
    const all = new URL(req.url).searchParams.get("all") === "1";
    const orders = (await listOrders())
      .filter((o) => o.status === "received" && (all || !o.posSync?.acked))
      .reverse()
      .map((o) => ({
        id: o.id, createdAt: o.createdAt, paymentMethod: o.paymentMethod, paymentStatus: o.paymentStatus,
        customer: o.customer,
        items: o.items.map((i) => ({ sku: i.sku ?? null, slug: i.slug, name: i.name, price: i.price, qty: i.qty })),
        subtotal: o.subtotal, deliveryFee: o.deliveryFee, total: o.total,
      }));
    return { orders };
  });
