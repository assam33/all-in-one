import { applyPosSync, readCatalog, refreshCatalog } from "@/lib/catalog";
import { jsonBody } from "@/lib/admin";
import { AppError } from "@/lib/errors";
import { posGuard } from "@/lib/pos";

// POS reads the catalogue (to match SKUs / see what the website has).
export const GET = (req: Request) =>
  posGuard(req, async () => ({
    products: (await readCatalog()).products.map((p) => ({ sku: p.sku ?? null, slug: p.slug, name: p.name, price: p.price, stock: p.stock, category: p.category, active: p.active })),
  }));

// POS pushes price / stock / new items. Body: { "products": [ { "sku": "BRG-01", "price": 499, "stock": 25 }, ... ] }
export const PUT = (req: Request) =>
  posGuard(req, async () => {
    const products = ((await jsonBody(req)) as { products?: unknown } | null)?.products;
    if (!Array.isArray(products)) throw new AppError('Body must be { "products": [ ... ] }');
    if (products.length > 2000) throw new AppError("Maximum 2000 products per request");
    const result = await applyPosSync(products, "api");
    refreshCatalog();
    return result;
  });
