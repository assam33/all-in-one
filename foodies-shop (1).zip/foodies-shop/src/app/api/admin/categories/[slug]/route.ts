import { guard } from "@/lib/admin";
import { deleteCategory, refreshCatalog } from "@/lib/catalog";

export const DELETE = (req: Request, { params }: { params: Promise<{ slug: string }> }) =>
  guard(req, async () => {
    const res = await deleteCategory((await params).slug);
    refreshCatalog();
    return res;
  });
