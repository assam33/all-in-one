import { guard, jsonBody } from "@/lib/admin";
import { readCatalog, refreshCatalog, saveCategory } from "@/lib/catalog";
import { AppError } from "@/lib/errors";
import { categorySchema } from "@/lib/schemas";

export const GET = (req: Request) => guard(req, async () => ({ categories: (await readCatalog()).categories }));

// Create (no slug) or rename (slug of the existing category).
export const POST = (req: Request) =>
  guard(req, async () => {
    const body = await jsonBody(req);
    const parsed = categorySchema.safeParse(body);
    if (!parsed.success) throw new AppError(parsed.error.issues[0]?.message ?? "Invalid category");
    const slug = (body as { slug?: unknown }).slug;
    const category = await saveCategory(parsed.data, typeof slug === "string" ? slug : undefined);
    refreshCatalog();
    return { category };
  });
