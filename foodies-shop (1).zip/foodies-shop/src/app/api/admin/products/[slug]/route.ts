import { guard } from "@/lib/admin";
import { deleteProduct, refreshCatalog } from "@/lib/catalog";

export const DELETE = (req: Request, { params }: { params: Promise<{ slug: string }> }) =>
  guard(req, async () => {
    const res = await deleteProduct((await params).slug);
    refreshCatalog();
    return res;
  });
