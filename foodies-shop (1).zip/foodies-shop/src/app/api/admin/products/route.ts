import { guard, jsonBody } from "@/lib/admin";
import { readCatalog, refreshCatalog, saveProduct } from "@/lib/catalog";
import { AppError } from "@/lib/errors";
import { productSchema } from "@/lib/schemas";

export const GET = (req: Request) =>
  guard(req, async () => {
    const c = await readCatalog();
    return { products: c.products, categories: c.categories };
  });

// Create (no slug) or update (slug of the existing product).
export const POST = (req: Request) =>
  guard(req, async () => {
    const body = await jsonBody(req);
    const parsed = productSchema.safeParse(body);
    if (!parsed.success) throw new AppError(parsed.error.issues[0]?.message ?? "Invalid product");
    const slug = (body as { slug?: unknown }).slug;
    const product = await saveProduct(parsed.data, typeof slug === "string" ? slug : undefined);
    refreshCatalog();
    return { product };
  });
