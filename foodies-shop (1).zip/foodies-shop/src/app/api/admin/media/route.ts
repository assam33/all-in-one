import { guard, jsonBody } from "@/lib/admin";
import { readCatalog, refreshCatalog, saveMedia } from "@/lib/catalog";
import { AppError } from "@/lib/errors";
import { mediaSchema } from "@/lib/schemas";

export const GET = (req: Request) => guard(req, async () => ({ media: (await readCatalog()).media }));

export const POST = (req: Request) =>
  guard(req, async () => {
    const parsed = mediaSchema.safeParse(await jsonBody(req));
    if (!parsed.success) throw new AppError(parsed.error.issues[0]?.message ?? "Invalid media settings");
    const media = await saveMedia(parsed.data);
    refreshCatalog();
    return { media };
  });
