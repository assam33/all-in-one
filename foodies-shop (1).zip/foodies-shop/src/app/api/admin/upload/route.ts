import { guard } from "@/lib/admin";
import { AppError } from "@/lib/errors";
import { saveUpload } from "@/lib/uploads";

export const POST = (req: Request) =>
  guard(req, async () => {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) throw new AppError("No file received");
    return { url: await saveUpload(file, form.get("kind") === "video" ? "video" : "image") };
  });
