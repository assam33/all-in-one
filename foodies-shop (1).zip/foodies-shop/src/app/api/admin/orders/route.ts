import { guard } from "@/lib/admin";
import { listOrders } from "@/lib/orders";

export const GET = (req: Request) => guard(req, async () => ({ orders: await listOrders() }));
