import { guard, jsonBody } from "@/lib/admin";
import { AppError } from "@/lib/errors";
import { cancelOrder, getOrder, markPaid, updateOrder } from "@/lib/orders";
import { notifyPos } from "@/lib/pos";

export const POST = (req: Request, { params }: { params: Promise<{ id: string }> }) =>
  guard(req, async () => {
    const action = ((await jsonBody(req)) as { action?: string } | null)?.action;
    const id = (await params).id;
    if (action === "mark_paid") return { order: await markPaid(id) };
    if (action === "reject_payment") return { order: await updateOrder(id, (o) => (o.paymentStatus === "paid" ? o : { ...o, paymentStatus: "failed" })) };
    if (action === "cancel") return { order: await cancelOrder(id) };
    if (action === "resend_pos") {
      const order = await getOrder(id);
      if (!order) throw new AppError("Order not found", 404);
      const r = await notifyPos(order, "order.confirmed");
      if (!r.ok) throw new AppError(`POS did not accept the order: ${r.error}`, 502);
      return { order: await getOrder(id) };
    }
    throw new AppError("Unknown action");
  });
