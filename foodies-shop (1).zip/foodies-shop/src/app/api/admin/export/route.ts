import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/admin";
import { readCatalog } from "@/lib/catalog";
import { toCsv } from "@/lib/csv";

export async function GET(req: Request) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { products } = await readCatalog();
  const csv = toCsv([
    ["sku", "slug", "name", "price", "stock", "category", "active"],
    ...products.map((p) => [p.sku, p.slug, p.name, p.price, p.stock ?? "untracked", p.category, p.active]),
  ]);
  return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="products.csv"' } });
}
