import { guard, jsonBody } from "@/lib/admin";
import { applyPosSync, readCatalog, refreshCatalog } from "@/lib/catalog";
import { parseCsv } from "@/lib/csv";
import { AppError } from "@/lib/errors";
import { deliver, posKeyConfigured, webhookConfigured } from "@/lib/pos";

const num = (v?: string) => (v === undefined || v === "" ? undefined : Number(v));

export const GET = (req: Request) =>
  guard(req, async () => {
    const c = await readCatalog();
    return {
      posLog: c.posLog,
      inboundKeySet: posKeyConfigured(),
      webhookSet: webhookConfigured(),
      products: c.products.length,
      withSku: c.products.filter((p) => p.sku).length,
    };
  });

export const POST = (req: Request) =>
  guard(req, async () => {
    const body = (await jsonBody(req)) as { action?: string; csv?: string } | null;
    if (body?.action === "test_webhook") return deliver("test.ping", { message: "Hello from Foodies admin" });
    if (body?.action === "import" && typeof body.csv === "string") {
      const rows = parseCsv(body.csv);
      if (rows.length === 0) throw new AppError("The CSV has no rows. First line must be the header: sku,name,price,stock,category,active");
      if (rows.length > 2000) throw new AppError("Maximum 2000 rows per import");
      const items = rows.map((r) => ({
        sku: r.sku || undefined,
        slug: r.slug || undefined,
        name: r.name || undefined,
        price: num(r.price),
        stock: r.stock?.toLowerCase() === "untracked" ? null : num(r.stock),
        category: r.category || undefined,
        active: r.active ? ["true", "yes", "1"].includes(r.active.toLowerCase()) : undefined,
      }));
      const result = await applyPosSync(items, "csv");
      refreshCatalog();
      return result;
    }
    throw new AppError("Unknown action");
  });
