import { NextResponse } from "next/server";
import { adminConfigured, checkAdminPassword, sessionCookie } from "@/lib/admin";

const fails = new Map<string, { n: number; t: number }>(); // basic brute-force throttle (per process)

export async function POST(req: Request) {
  if (!adminConfigured()) return NextResponse.json({ error: "ADMIN_TOKEN is not set on the server (min 8 characters)." }, { status: 503 });
  const ip = (req.headers.get("x-forwarded-for") ?? "local").split(",")[0].trim();
  const f = fails.get(ip);
  if (f && Date.now() - f.t < 15 * 60_000 && f.n >= 10) return NextResponse.json({ error: "Too many attempts. Try again in 15 minutes." }, { status: 429 });

  const { password } = ((await req.json().catch(() => ({}))) ?? {}) as { password?: string };
  if (!password || !checkAdminPassword(password)) {
    fails.set(ip, { n: (f && Date.now() - f.t < 15 * 60_000 ? f.n : 0) + 1, t: Date.now() });
    return NextResponse.json({ error: "Wrong password" }, { status: 401 });
  }
  fails.delete(ip);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(sessionCookie());
  return res;
}
