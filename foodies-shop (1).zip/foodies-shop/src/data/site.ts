// Single place for all business/brand content. Edit here, not in components.
export const site = {
  name: "Foodies",
  company: "Jatala Internationals",
  description: "Order bakery, deli, pizza, burgers and pan-asian food online from Jatala Internationals.",
  currency: "Rs",
  currencyCode: "PKR", // ISO code sent to the card gateway
  deliveryFee: 0, // flat delivery fee added at checkout
  minOrder: 0, // minimum cart subtotal to check out (0 = no minimum)
  payments: {
    // "Online payment": customer sends money, then submits the transaction ID. You verify it in /admin.
    // REPLACE the placeholder account details below before going live.
    transfer: {
      enabled: true,
      accounts: [
        { name: "JazzCash", title: "ACCOUNT TITLE", number: "03XX-XXXXXXX" },
        { name: "Easypaisa", title: "ACCOUNT TITLE", number: "03XX-XXXXXXX" },
        { name: "Bank transfer", title: "ACCOUNT TITLE", number: "PK00 XXXX 0000 0000 0000 0000", bank: "BANK NAME" },
      ] as { name: string; title: string; number: string; bank?: string }[],
    },
  },
  location: "Saudi Arabia, Makkah",
  announcement: "Online delivery option available",
  timings: [
    "Friday break time 12:30 PM to 2:30 PM",
    "Kitchen operational after 12:00 PM to 03:00 AM",
    "Delivery timings are 12:00 PM to 03:00 AM",
  ],
  about:
    "Jatala Internationals (JI) is established in 2025 by Chaudhary Ishtiaq Aslam, the father of SM.Assam and Taha Ishtaiq. JI started in Makkah, Saudi Arabia.",
  contact: {
    supportPhone: "03167519007",
    complaintPhone: "03167519007",
    uan: "055-751-9007-000",
    email: "info@jatalainternationals.com.pk",
  },
  social: { facebook: "https://www.facebook.com/", instagram: "#" },
  footerLinks: {
    site: [
      { label: "Bakery", href: "/category/bakery" },
      { label: "Grocery", href: "/category/others" },
      { label: "Pan Asian", href: "/category/pan-asian" },
      { label: "Deals", href: "/category/deals" },
      { label: "Make a box", href: "/category/special" },
      { label: "Customized Cake", href: "/category/cakes" },
    ],
    useful: [
      { label: "Privacy Policy", href: "/info/privacy-policy" },
      { label: "Terms & Conditions", href: "/info/terms" },
      { label: "Franchise Form", href: "/info/franchise" },
      { label: "Download App", href: "/info/download-app" },
      { label: "Career", href: "/info/careers" },
      { label: "Contact", href: "/info/contact" },
    ],
  },
};

// Simple content pages served at /info/[slug]
export const infoPages: Record<string, { title: string; body: string[] }> = {
  "privacy-policy": { title: "Privacy Policy", body: ["Privacy policy content goes here."] },
  terms: { title: "Terms & Conditions", body: ["Terms and conditions content goes here."] },
  franchise: { title: "Franchise Form", body: ["Franchise enquiry form coming soon. For now, please contact us using the details below."] },
  "download-app": { title: "Download App", body: ["Our mobile app is coming soon."] },
  careers: { title: "Career", body: ["We are always looking for passionate people. Send your CV to our email below."] },
  contact: { title: "Contact Us", body: ["We would love to hear from you. Reach us using the details below."] },
};
