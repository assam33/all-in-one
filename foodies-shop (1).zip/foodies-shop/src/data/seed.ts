// First-run content. After the first admin change everything lives in .data/catalog.json
// (see src/lib/catalog.ts) and is edited from /admin. Delete that file to reset to this.
import type { CategoryRecord, Media, Product } from "@/types";
import { slugify } from "@/lib/format";
import { site } from "./site";

const tree: [string, string[]?][] = [
  ["Bakery", ["Bread", "Brownies", "Cakes", "Customise Icecream", "Donuts & Cupcake", "Pastries", "Rusk", "Salad", "Buns", "Biscuits & Khatai", "Cake Rusk", "Confectionery", "JI Dairy", "Puff Pastries", "Salted Snacks"]],
  ["Deli", ["Burgers", "Deli Fish", "JI New Arrivals", "Peri Peri Chicken", "Crispy Fried Chicken", "Italian Cuisine", "Pizza", "Sandwich"]],
  ["Pan Asian", ["Classic Entree", "Premium Entree", "Starters", "Chow Main", "Premium Entree (Seafood)"]],
  ["JI Icecream"], ["Drinks"], ["Eatables"], ["Special"], ["Deals"], ["Others"],
];

export const seedCategories: CategoryRecord[] = tree.flatMap(([label, kids = []]) => [
  { slug: slugify(label), label },
  ...kids.map((k) => ({ slug: slugify(k), label: k, parent: slugify(label) })),
]);

const p = (slug: string, name: string, price: number, image: string, category: string): Product => ({ slug, name, price, image, category, active: true, stock: null });

export const seedProducts: Product[] = [
  p("the-famous-soup", "The Famous Soup", 600, "/images/products/soup-1.webp", "starters"),
  p("szechuan-soup", "Szechuan Soup (Single Serving)", 499, "/images/products/soup-2.webp", "starters"),
  p("hot-and-sour-soup", "Hot & Sour Soup (Single Serving)", 499, "/images/products/soup-3.webp", "starters"),
  p("chicken-corn-soup", "Chicken Corn Soup (Single Serving)", 499, "/images/products/soup-4.webp", "starters"),
  p("crispy-chicken-burger", "Crispy Chicken Burger", 450, "/images/products/burger-1.webp", "burgers"),
  p("peri-peri-chicken-burger", "Peri Peri Chicken Burger", 799, "/images/products/burger-2.webp", "burgers"),
  p("hot-chick-burger", "Hot Chick Burger", 599, "/images/products/burger-3.webp", "burgers"),
  p("double-beef-cheese-burger", "Double Beef Cheese Burger", 899, "/images/products/burger-4.webp", "burgers"),
  p("peri-peri-pizza-l", "Peri Peri Pizza (L)", 2200, "/images/products/pizza-1.webp", "pizza"),
  p("supreme-beef-pizza-l", "Supreme Beef Pizza (L)", 2200, "/images/products/pizza-2.webp", "pizza"),
  p("fajita-sandwich", "Fajita Sandwich", 599, "/images/products/sandwich-1.webp", "sandwich"),
  p("bbq-sandwich", "BBQ Sandwich", 599, "/images/products/sandwich-2.webp", "sandwich"),
  // SAMPLE DATA - replace from /admin/products
  p("fresh-bread", "Fresh Bread", 350, "/images/products/bakery-1.avif", "bread"),
  p("butter-croissant", "Butter Croissant", 400, "/images/products/bakery-1.avif", "pastries"),
  p("belgian-waffle", "Belgian Waffle", 550, "/images/products/bakery-1.avif", "pastries"),
];

export const seedMedia: Media = {
  heroSlides: [
    ["company.webp", "Foodies"], ["poster-1.webp", "Promotion 2"], ["poster-3.webp", "Promotion 3"], ["hero-1.jpg", "Promotion 4"],
    ["hero-2.webp", "Promotion 5"], ["hero-3.avif", "Promotion 6"], ["hero-4.webp", "Promotion 7"],
  ].map(([file, alt], i) => ({ id: `seed-${i + 1}`, src: `/images/hero/${file}`, alt })),
  promo: {
    src: "/videos/pizza.mp4",
    heading: "Delicious Slices, Crafted With Passion!",
    text: `Indulge in the perfect blend of cheesy goodness and mouth-watering toppings with ${site.company}' irresistible pizzas.`,
  },
};
