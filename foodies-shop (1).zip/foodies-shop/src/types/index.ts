export type Product = {
  slug: string; // unique id + URL segment (never changes)
  sku?: string; // code shared with your POS
  name: string;
  price: number;
  image: string;
  category: string; // category slug
  description?: string;
  active: boolean; // false = hidden from the shop
  stock: number | null; // null = stock is not tracked (always available)
  updatedAt?: string;
};

export type CartLine = Pick<Product, "slug" | "name" | "price" | "image"> & { qty: number };

export type NavChild = { slug: string; label: string };
export type Category = { slug: string; label: string; children?: NavChild[] }; // tree node for menus
export type CategoryRecord = { slug: string; label: string; parent?: string }; // as stored
export type CategoryMatch = { slug: string; label: string; parent?: Category; children?: NavChild[] };

export type HeroSlide = { id: string; src: string; alt: string };
export type PromoVideo = { src: string; heading: string; text: string };
export type Media = { heroSlides: HeroSlide[]; promo: PromoVideo };
export type PosLogEntry = { at: string; source: "api" | "csv"; created: number; updated: number; errors: string[] };
export type Catalog = { categories: CategoryRecord[]; products: Product[]; media: Media; posLog: PosLogEntry[] };

export type PaymentMethod = "cod" | "transfer" | "card";
export type PaymentStatus = "unpaid" | "awaiting_verification" | "paid" | "failed";
export type OrderStatus = "pending_payment" | "received" | "cancelled";

export type Order = {
  id: string;
  createdAt: string;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  paymentRef?: string; // transaction ID entered by the customer (bank / wallet transfer)
  gatewaySession?: string; // card gateway checkout session id
  posSync?: { status: "sent" | "failed"; attempts: number; at: string; error?: string; acked?: boolean };
  customer: { name: string; phone: string; address: string; notes?: string };
  items: { slug: string; sku?: string; name: string; price: number; qty: number }[];
  subtotal: number;
  deliveryFee: number;
  total: number;
};
