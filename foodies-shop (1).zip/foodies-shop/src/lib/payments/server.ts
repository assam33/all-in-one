import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import type { Order, PaymentMethod } from "@/types";
import { site } from "@/data/site";
import { markFailed, markPaid, updateOrder } from "@/lib/orders";

/**
 * Card payments use a hosted gateway page, so card numbers never touch this server.
 *  - STRIPE_SECRET_KEY set  -> Stripe Checkout (real payments)
 *  - otherwise, in development (or PAYMENT_MOCK=true) -> built-in TEST gateway at /pay/mock/[id]
 *  - otherwise card is hidden
 * To use another gateway (Safepay, PayFast, ...) add a branch in startCardPayment/verifyCardPayment.
 */
export type CardProvider = "stripe" | "mock";

export function cardProvider(): CardProvider | null {
  if (process.env.STRIPE_SECRET_KEY) return "stripe";
  if (process.env.PAYMENT_MOCK === "true" || process.env.NODE_ENV !== "production") return "mock";
  return null;
}

export function availableMethods(): PaymentMethod[] {
  const methods: PaymentMethod[] = ["cod"];
  if (site.payments.transfer.enabled) methods.push("transfer");
  if (cardProvider()) methods.push("card");
  return methods;
}

const siteUrl = () => (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, "");

/** Creates a payment session and returns the URL the customer must be sent to. */
export async function startCardPayment(order: Order): Promise<string> {
  if (cardProvider() === "mock") return `/pay/mock/${order.id}`;

  const lines = order.items.map((i) => ({ name: i.name, amount: i.price, qty: i.qty }));
  if (order.deliveryFee) lines.push({ name: "Delivery", amount: order.deliveryFee, qty: 1 });

  const body = new URLSearchParams({
    mode: "payment",
    success_url: `${siteUrl()}/order/${order.id}`,
    cancel_url: `${siteUrl()}/order/${order.id}`,
    client_reference_id: order.id,
    "metadata[orderId]": order.id,
  });
  lines.forEach((l, n) => {
    body.set(`line_items[${n}][quantity]`, String(l.qty));
    body.set(`line_items[${n}][price_data][currency]`, site.currencyCode.toLowerCase());
    body.set(`line_items[${n}][price_data][unit_amount]`, String(Math.round(l.amount * 100)));
    body.set(`line_items[${n}][price_data][product_data][name]`, l.name);
  });

  const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`, "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  const data = await res.json();
  if (!res.ok || !data.url) throw new Error(data.error?.message ?? "Could not create Stripe session");
  await updateOrder(order.id, (o) => ({ ...o, gatewaySession: data.id }));
  return data.url as string;
}

/** Asks the gateway for the latest status (covers the customer returning before the webhook arrives). */
export async function verifyCardPayment(order: Order): Promise<Order> {
  if (order.paymentMethod !== "card" || order.paymentStatus === "paid" || !order.gatewaySession || cardProvider() !== "stripe") return order;
  try {
    const res = await fetch(`https://api.stripe.com/v1/checkout/sessions/${order.gatewaySession}`, {
      headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}` },
      cache: "no-store",
    });
    const s = await res.json();
    if (s.payment_status === "paid") return await markPaid(order.id, s.id);
    if (s.status === "expired") return await markFailed(order.id);
  } catch (err) {
    console.error("Payment verification failed:", err);
  }
  return order;
}

/** Verifies the `Stripe-Signature` header of a webhook (HMAC-SHA256, 5 min tolerance). */
export function verifyStripeSignature(raw: string, header: string): boolean {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret || !header) return false;
  const pairs = header.split(",").map((p) => p.split("=") as [string, string]);
  const t = pairs.find(([k]) => k === "t")?.[1];
  if (!t || Math.abs(Date.now() / 1000 - Number(t)) > 300) return false;
  const expected = createHmac("sha256", secret).update(`${t}.${raw}`).digest("hex");
  return pairs.some(([k, v]) => k === "v1" && v.length === expected.length && timingSafeEqual(Buffer.from(v), Buffer.from(expected)));
}
