import type { Order, PaymentMethod } from "@/types";

// Safe to import on the client (no secrets).
export const methodInfo: Record<PaymentMethod, { label: string; description: string }> = {
  cod: { label: "Cash on delivery", description: "Pay in cash when your order arrives." },
  transfer: { label: "Online payment (JazzCash / Easypaisa / Bank)", description: "Send the amount, then enter the transaction ID. Your order is confirmed after we verify it." },
  card: { label: "Debit / Credit card", description: "Pay securely on our payment partner's page. We never see or store your card details." },
};

export function paymentStatusLabel(o: Pick<Order, "paymentMethod" | "paymentStatus">) {
  if (o.paymentStatus === "paid") return "Paid";
  if (o.paymentStatus === "awaiting_verification") return "Verifying payment";
  if (o.paymentStatus === "failed") return "Payment failed";
  return o.paymentMethod === "cod" ? "Pay on delivery" : "Awaiting payment";
}
