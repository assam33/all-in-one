import "server-only";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

/**
 * Tiny JSON-file "database" with a write queue (no lost updates).
 * To move to a real database, re-implement `read` and `update` of the stores that use this
 * (catalog.ts, orders.ts) - nothing else in the app touches the files.
 */
export function jsonStore<T>(file: string, seed: () => T) {
  const full = path.resolve(/*turbopackIgnore: true*/ file);
  let queue: Promise<unknown> = Promise.resolve();

  const read = async (): Promise<T> => {
    try {
      return JSON.parse(await readFile(full, "utf8"));
    } catch {
      return seed();
    }
  };

  /** `fn` may mutate the value in place; it is saved only if `fn` does not throw. */
  const update = <R>(fn: (value: T) => R | Promise<R>): Promise<R> => {
    const run = queue.then(async () => {
      const value = await read();
      const result = await fn(value);
      await mkdir(path.dirname(full), { recursive: true });
      await writeFile(full, JSON.stringify(value, null, 2));
      return result;
    });
    queue = run.catch(() => {});
    return run;
  };

  return { read, update };
}
