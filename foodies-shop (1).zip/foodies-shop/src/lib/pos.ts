import "server-only";
import { createHmac } from "node:crypto";
import type { Order } from "@/types";
import { safeEqual } from "./crypto";
import { updateOrder } from "./orders";

/** Inbound: the POS calls our /api/pos/* endpoints with `Authorization: Bearer <POS_API_KEY>`. */
export const posKeyConfigured = () => (process.env.POS_API_KEY ?? "").length >= 16;
export function isPos(req: Request) {
  const key = process.env.POS_API_KEY;
  if (!key || key.length < 16) return false;
  const h = req.headers.get("authorization") ?? "";
  return h.startsWith("Bearer ") && safeEqual(h.slice(7), key);
}

/** Outbound: we POST events to POS_WEBHOOK_URL, signed with HMAC-SHA256 (header X-Signature: sha256=<hex>). */
export const webhookConfigured = () => Boolean(process.env.POS_WEBHOOK_URL);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function deliver(event: string, payload: object): Promise<{ ok: boolean; attempts: number; error?: string }> {
  const url = process.env.POS_WEBHOOK_URL;
  if (!url) return { ok: false, attempts: 0, error: "POS_WEBHOOK_URL is not set" };
  const body = JSON.stringify({ event, sentAt: new Date().toISOString(), ...payload });
  const signature = createHmac("sha256", process.env.POS_WEBHOOK_SECRET ?? "").update(body).digest("hex");
  let error = "";
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Event": event, "X-Signature": `sha256=${signature}` },
        body,
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) return { ok: true, attempts: attempt };
      error = `HTTP ${res.status}`;
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
    }
    if (attempt < 3) await sleep(attempt * 1500);
  }
  return { ok: false, attempts: 3, error };
}

export async function notifyPos(order: Order, event = "order.confirmed") {
  if (!webhookConfigured()) return { ok: false, attempts: 0, error: "POS_WEBHOOK_URL is not set" };
  const r = await deliver(event, { order });
  try {
    await updateOrder(order.id, (o) => ({
      ...o,
      posSync: { status: r.ok ? "sent" : "failed", attempts: r.attempts, at: new Date().toISOString(), error: r.error, acked: o.posSync?.acked },
    }));
  } catch {
    /* order vanished - nothing to record */
  }
  return r;
}

/** Auth + error mapping for /api/pos/* routes. */
export async function posGuard(req: Request, fn: () => Promise<unknown>) {
  const { NextResponse } = await import("next/server");
  if (!isPos(req)) return NextResponse.json({ error: "Unauthorized (send Authorization: Bearer <POS_API_KEY>)" }, { status: 401 });
  const { respond } = await import("./admin");
  return respond(fn);
}
