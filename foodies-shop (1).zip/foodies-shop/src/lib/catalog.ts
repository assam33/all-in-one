import "server-only";
import { revalidatePath } from "next/cache";
import { cache } from "react";
import { seedCategories, seedMedia, seedProducts } from "@/data/seed";
import type { Catalog, CategoryMatch, CategoryRecord, Category, Media, Product } from "@/types";
import { AppError } from "./errors";
import { slugify } from "./format";
import { posItemSchema, type ProductInput } from "./schemas";
import { jsonStore } from "./store";

const store = jsonStore<Catalog>(process.env.CATALOG_FILE ?? ".data/catalog.json", () =>
  structuredClone({ categories: seedCategories, products: seedProducts, media: seedMedia, posLog: [] }),
);

export const getCatalog = cache(() => store.read()); // de-duplicated per request (pages)
export const readCatalog = () => store.read(); // always fresh (API routes)

/** Call after any change so the (statically generated) shop pages rebuild. */
export function refreshCatalog() {
  try {
    revalidatePath("/", "layout");
  } catch {
    /* not inside a request (scripts/tests) */
  }
}

// ---------- reading (public shop) ----------
export const isSoldOut = (p: Pick<Product, "stock">) => p.stock !== null && p.stock <= 0;

export function buildTree(cats: CategoryRecord[]): Category[] {
  return cats
    .filter((c) => !c.parent)
    .map((c) => {
      const kids = cats.filter((k) => k.parent === c.slug).map((k) => ({ slug: k.slug, label: k.label }));
      return { slug: c.slug, label: c.label, children: kids.length ? kids : undefined };
    });
}

export const getCategoryTree = async () => buildTree((await getCatalog()).categories);

export async function findCategory(slug: string): Promise<CategoryMatch | undefined> {
  const cats = (await getCatalog()).categories;
  const c = cats.find((x) => x.slug === slug);
  if (!c) return undefined;
  const tree = buildTree(cats);
  if (!c.parent) return { slug, label: c.label, children: tree.find((t) => t.slug === slug)?.children };
  return { slug, label: c.label, parent: tree.find((t) => t.slug === c.parent) };
}

/** A parent category includes all of its children's products. */
const withChildren = (slug: string, cats: CategoryRecord[]) => [slug, ...cats.filter((c) => c.parent === slug).map((c) => c.slug)];

export async function getProductsIn(...slugs: string[]) {
  const c = await getCatalog();
  const set = new Set(slugs.flatMap((s) => withChildren(s, c.categories)));
  return c.products.filter((p) => p.active && set.has(p.category));
}

export const getProduct = async (slug: string) => (await getCatalog()).products.find((p) => p.slug === slug && p.active);

export async function searchProducts(q: string) {
  const term = q.trim().toLowerCase();
  if (!term) return [];
  return (await getCatalog()).products.filter((p) => p.active && (p.name.toLowerCase().includes(term) || p.sku?.toLowerCase() === term));
}

export async function getRelated(p: Product, limit = 4) {
  return (await getCatalog()).products.filter((x) => x.active && x.category === p.category && x.slug !== p.slug).slice(0, limit);
}

/** Minimal public product list sent to the browser (cart prices, stock limits). */
export async function getCatalogProducts() {
  return (await getCatalog()).products.filter((p) => p.active).map(({ slug, name, price, image, stock }) => ({ slug, name, price, image, stock }));
}

// ---------- admin: products ----------
const uniqueSlug = (base: string, taken: Set<string>) => {
  const root = slugify(base) || "item";
  let s = root;
  for (let n = 2; taken.has(s); n++) s = `${root}-${n}`;
  return s;
};

export const saveProduct = (input: ProductInput, slug?: string) =>
  store.update((c) => {
    if (!c.categories.some((k) => k.slug === input.category)) throw new AppError("Unknown category");
    if (input.sku && c.products.some((p) => p.sku === input.sku && p.slug !== slug)) throw new AppError("This SKU is already used by another product");
    const data = { ...input, sku: input.sku || undefined, description: input.description || undefined, updatedAt: new Date().toISOString() };
    if (slug) {
      const i = c.products.findIndex((p) => p.slug === slug);
      if (i < 0) throw new AppError("Product not found", 404);
      c.products[i] = { ...c.products[i], ...data };
      return c.products[i];
    }
    const product: Product = { ...data, slug: uniqueSlug(input.name, new Set(c.products.map((p) => p.slug))) };
    c.products.push(product);
    return product;
  });

export const deleteProduct = (slug: string) =>
  store.update((c) => {
    const i = c.products.findIndex((p) => p.slug === slug);
    if (i < 0) throw new AppError("Product not found", 404);
    c.products.splice(i, 1);
    return { ok: true };
  });

// ---------- admin: categories ----------
export const saveCategory = (input: { label: string; parent?: string }, slug?: string) =>
  store.update((c) => {
    if (slug) {
      const cat = c.categories.find((k) => k.slug === slug);
      if (!cat) throw new AppError("Category not found", 404);
      cat.label = input.label; // the slug (URL) never changes
      return cat;
    }
    if (input.parent) {
      const parent = c.categories.find((k) => k.slug === input.parent);
      if (!parent || parent.parent) throw new AppError("Choose a top-level category as the parent");
    }
    const cat: CategoryRecord = { slug: uniqueSlug(input.label, new Set(c.categories.map((k) => k.slug))), label: input.label, parent: input.parent || undefined };
    c.categories.push(cat);
    return cat;
  });

export const deleteCategory = (slug: string) =>
  store.update((c) => {
    if (!c.categories.some((k) => k.slug === slug)) throw new AppError("Category not found", 404);
    if (c.categories.some((k) => k.parent === slug)) throw new AppError("Delete its sub-categories first");
    if (c.products.some((p) => p.category === slug)) throw new AppError("Move or delete the products in this category first");
    c.categories = c.categories.filter((k) => k.slug !== slug);
    return { ok: true };
  });

// ---------- admin: media ----------
export const saveMedia = (media: Media) =>
  store.update((c) => {
    c.media = media;
    return media;
  });

// ---------- stock ----------
type Wanted = { slug: string; qty: number };

/** Checks availability and takes the stock in one atomic step. Returns the priced order lines. */
export const reserveStock = (items: Wanted[]) =>
  store.update((c) => {
    const merged = new Map<string, number>();
    items.forEach((i) => merged.set(i.slug, (merged.get(i.slug) ?? 0) + i.qty));
    const lines = [...merged].map(([slug, qty]) => {
      const p = c.products.find((x) => x.slug === slug && x.active);
      if (!p) throw new AppError("Some items in your cart are no longer available.");
      if (p.stock !== null && p.stock < qty) throw new AppError(p.stock === 0 ? `"${p.name}" is out of stock.` : `Only ${p.stock} of "${p.name}" left.`);
      return { p, qty };
    });
    for (const { p, qty } of lines) if (p.stock !== null) p.stock -= qty;
    return lines.map(({ p, qty }) => ({ slug: p.slug, sku: p.sku, name: p.name, price: p.price, qty }));
  });

export const releaseStock = (items: Wanted[]) =>
  store.update((c) => {
    for (const i of items) {
      const p = c.products.find((x) => x.slug === i.slug);
      if (p && p.stock !== null) p.stock += i.qty;
    }
  });

// ---------- POS sync ----------
/** Upserts products by sku (or slug). The POS is the source of truth for price + stock. */
export const applyPosSync = (rawItems: unknown[], source: "api" | "csv") =>
  store.update((c) => {
    let created = 0;
    let updated = 0;
    const errors: string[] = [];
    const now = new Date().toISOString();

    rawItems.forEach((raw, idx) => {
      const n = idx + 1;
      const r = posItemSchema.safeParse(raw);
      if (!r.success) return void errors.push(`#${n}: ${r.error.issues[0]?.message}`);
      const it = r.data;
      const cat = it.category ? c.categories.find((k) => k.slug === it.category || k.label.toLowerCase() === it.category!.toLowerCase()) : undefined;
      if (it.category && !cat) return void errors.push(`#${n}: unknown category "${it.category}"`);

      const p = c.products.find((x) => (it.sku && x.sku === it.sku) || (it.slug && x.slug === it.slug));
      if (p) {
        if (it.name !== undefined) p.name = it.name;
        if (it.price !== undefined) p.price = it.price;
        if (it.stock !== undefined) p.stock = it.stock;
        if (it.active !== undefined) p.active = it.active;
        if (cat) p.category = cat.slug;
        if (it.sku && !p.sku) p.sku = it.sku;
        p.updatedAt = now;
        updated++;
        return;
      }
      if (!it.sku || !it.name || it.price === undefined || !cat) return void errors.push(`#${n}: a new product needs sku, name, price and a valid category`);
      c.products.push({
        slug: uniqueSlug(it.name, new Set(c.products.map((x) => x.slug))),
        sku: it.sku, name: it.name, price: it.price, category: cat.slug,
        image: "/images/placeholder.webp",
        active: it.active ?? false, // hidden until you add a photo and publish it in /admin
        stock: it.stock ?? null,
        updatedAt: now,
      });
      created++;
    });

    c.posLog.unshift({ at: now, source, created, updated, errors: errors.slice(0, 20) });
    c.posLog.splice(20);
    return { created, updated, errors };
  });
