import "server-only";
import { randomBytes } from "node:crypto";
import type { Order } from "@/types";
import { site } from "@/data/site";
import { refreshCatalog, releaseStock, reserveStock } from "./catalog";
import { AppError } from "./errors";
import { formatPrice } from "./format";
import type { OrderInput } from "./schemas";
import { jsonStore } from "./store";

export { AppError as OrderError } from "./errors";

/** Orders live in a JSON file for now; swap `store` for a database in production. */
const store = jsonStore<Order[]>(process.env.ORDERS_FILE ?? ".data/orders.json", () => []);

export const getOrder = async (id: string) => (await store.read()).find((o) => o.id === id.toUpperCase());
export const listOrders = async () => (await store.read()).reverse();

// POS is notified in the background (dynamic import avoids a circular dependency).
function pushToPos(order: Order, event: string) {
  void import("./pos").then((m) => m.notifyPos(order, event)).catch((e) => console.error("POS notify failed:", e));
}

export async function createOrder(input: OrderInput): Promise<Order> {
  // Prices always come from the server catalogue; stock is taken atomically (throws if not enough).
  const items = await reserveStock(input.items);
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const order: Order = {
    id: `JI-${randomBytes(4).toString("hex").toUpperCase()}`,
    createdAt: new Date().toISOString(),
    // Cash on delivery is confirmed immediately; other methods wait for payment.
    status: input.method === "cod" ? "received" : "pending_payment",
    paymentMethod: input.method,
    paymentStatus: "unpaid",
    customer: input.customer,
    items,
    subtotal,
    deliveryFee: site.deliveryFee,
    total: subtotal + site.deliveryFee,
  };
  try {
    if (subtotal < site.minOrder) throw new AppError(`Minimum order amount is ${formatPrice(site.minOrder)}.`);
    await store.update((all) => void all.push(order));
  } catch (err) {
    await releaseStock(items);
    throw err;
  }
  refreshCatalog();
  if (order.status === "received") pushToPos(order, "order.confirmed");
  return order;
}

export const updateOrder = (id: string, fn: (o: Order) => Order): Promise<Order> =>
  store.update((all) => {
    const i = all.findIndex((o) => o.id === id.toUpperCase());
    if (i < 0) throw new AppError("Order not found", 404);
    all[i] = fn(all[i]);
    return all[i];
  });

// Both are idempotent: gateways may deliver the same webhook more than once.
export async function markPaid(id: string, gatewaySession?: string) {
  const before = await getOrder(id);
  const after = await updateOrder(id, (o) =>
    o.paymentStatus === "paid"
      ? o
      : { ...o, paymentStatus: "paid", status: o.status === "cancelled" ? "cancelled" : "received", gatewaySession: gatewaySession ?? o.gatewaySession },
  );
  if (before && before.status !== "received" && after.status === "received") pushToPos(after, "order.confirmed");
  return after;
}

export const markFailed = (id: string) => updateOrder(id, (o) => (o.paymentStatus === "paid" ? o : { ...o, paymentStatus: "failed" }));

/** Cancels the order and puts its items back in stock. */
export async function cancelOrder(id: string) {
  const before = await getOrder(id);
  if (!before) throw new AppError("Order not found", 404);
  if (before.status === "cancelled") return before;
  const after = await updateOrder(id, (o) => ({ ...o, status: "cancelled" }));
  await releaseStock(after.items);
  refreshCatalog();
  if (before.status === "received") pushToPos(after, "order.cancelled");
  return after;
}
