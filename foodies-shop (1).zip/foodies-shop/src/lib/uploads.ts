import "server-only";
import { randomBytes } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { AppError } from "./errors";

/**
 * Uploaded files are stored on disk and served by /uploads/[name].
 * For production/serverless replace `saveUpload` (and the route) with S3 / Cloudinary / Supabase Storage.
 */
export const uploadDir = path.resolve(/*turbopackIgnore: true*/ process.env.UPLOAD_DIR ?? ".data/uploads");

const types: Record<string, string> = {
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", avif: "image/avif", gif: "image/gif",
  mp4: "video/mp4", webm: "video/webm",
};
const kinds = { image: ["jpg", "jpeg", "png", "webp", "avif", "gif"], video: ["mp4", "webm"] } as const;
const limits = { image: 8 * 1024 * 1024, video: 60 * 1024 * 1024 };

export const mimeOf = (name: string) => types[name.split(".").pop()?.toLowerCase() ?? ""];

// Check the real file signature, not just the extension.
function looksLike(buf: Buffer, ext: string) {
  const at = (i: number, s: string) => buf.subarray(i, i + s.length).toString("latin1") === s;
  if (ext === "jpg" || ext === "jpeg") return buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  if (ext === "png") return buf[0] === 0x89 && at(1, "PNG");
  if (ext === "gif") return at(0, "GIF8");
  if (ext === "webp") return at(0, "RIFF") && at(8, "WEBP");
  if (ext === "avif") return at(4, "ftyp") && (at(8, "avif") || at(8, "avis"));
  if (ext === "mp4") return at(4, "ftyp");
  if (ext === "webm") return buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3;
  return false;
}

export async function saveUpload(file: File, kind: "image" | "video"): Promise<string> {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  if (!(kinds[kind] as readonly string[]).includes(ext)) throw new AppError(`Allowed ${kind} types: ${kinds[kind].join(", ")}`);
  if (file.size > limits[kind]) throw new AppError(`File is too large (max ${limits[kind] / 1024 / 1024} MB)`);
  const buf = Buffer.from(await file.arrayBuffer());
  if (!looksLike(buf, ext)) throw new AppError("This file is not a valid " + kind);
  const name = `${Date.now().toString(36)}-${randomBytes(4).toString("hex")}.${ext}`;
  await mkdir(uploadDir, { recursive: true });
  await writeFile(path.join(uploadDir, name), buf);
  return `/uploads/${name}`;
}
