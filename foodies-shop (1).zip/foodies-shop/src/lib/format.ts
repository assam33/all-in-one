import { site } from "@/data/site";

export const formatPrice = (n: number) => `${site.currency} ${n.toLocaleString("en-US")}`;

export const slugify = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
