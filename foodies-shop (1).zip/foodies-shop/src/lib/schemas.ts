import { z } from "zod";

export const MAX_QTY = 50;
export const paymentMethods = ["cod", "transfer", "card"] as const;

// ---------- checkout ----------
export const customerSchema = z.object({
  name: z.string().trim().min(2, "Please enter your full name"),
  phone: z.string().trim().regex(/^\+?[\d\s-]{7,16}$/, "Enter a valid phone number"),
  address: z.string().trim().min(8, "Please enter your complete delivery address"),
  notes: z.string().trim().max(500, "Notes are too long").optional(),
});

export const orderSchema = z.object({
  customer: customerSchema,
  method: z.enum(paymentMethods, "Please choose a payment method"),
  items: z.array(z.object({ slug: z.string(), qty: z.number().int().min(1).max(MAX_QTY) })).min(1, "Your cart is empty"),
});

export const transferSchema = z.object({
  reference: z.string().trim().min(4, "Enter the transaction ID from your payment receipt").max(60, "Transaction ID is too long"),
});

export type OrderInput = z.infer<typeof orderSchema>;

// ---------- admin ----------
const assetPath = z
  .string()
  .regex(/^\/[\w\-./]+$/, "Please upload a file")
  .refine((s) => !s.includes(".."), "Invalid file path");

export const productSchema = z.object({
  name: z.string().trim().min(2, "Product name is too short").max(120),
  sku: z.string().trim().max(60).optional(),
  price: z.number("Enter a valid price").min(0, "Price cannot be negative").max(10_000_000),
  category: z.string().min(1, "Choose a category"),
  description: z.string().trim().max(1000).optional(),
  image: assetPath,
  active: z.boolean(),
  stock: z.number("Stock must be a number").int("Stock must be a whole number").min(0, "Stock cannot be negative").nullable(),
});
export type ProductInput = z.infer<typeof productSchema>;

export const categorySchema = z.object({
  label: z.string().trim().min(2, "Name is too short").max(60),
  parent: z.string().optional(),
});

export const mediaSchema = z.object({
  heroSlides: z.array(z.object({ id: z.string().min(1), src: assetPath, alt: z.string().trim().max(120) })).max(20),
  promo: z.object({ src: z.union([assetPath, z.literal("")]), heading: z.string().trim().max(120), text: z.string().trim().max(400) }),
});

// ---------- POS ----------
export const posItemSchema = z
  .object({
    sku: z.string().trim().max(60).optional(),
    slug: z.string().trim().max(120).optional(),
    name: z.string().trim().min(1).max(120).optional(),
    price: z.number().min(0).max(10_000_000).optional(),
    stock: z.number().int().min(0).nullable().optional(),
    category: z.string().trim().max(80).optional(),
    active: z.boolean().optional(),
  })
  .refine((i) => i.sku || i.slug, "each item needs a sku (or slug)");
export type PosItem = z.infer<typeof posItemSchema>;
