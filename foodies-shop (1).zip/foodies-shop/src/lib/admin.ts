import "server-only";
import { createHmac } from "node:crypto";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { safeEqual } from "./crypto";
import { AppError } from "./errors";

/**
 * Admin access = the ADMIN_TOKEN password (8+ chars) from the environment.
 * Browser: log in at /admin -> httpOnly SameSite=Strict cookie holding an HMAC of the password.
 * Scripts: send header `x-admin-token: <ADMIN_TOKEN>`.
 */
export const ADMIN_COOKIE = "admin_session";
const token = () => {
  const t = process.env.ADMIN_TOKEN;
  return t && t.length >= 8 ? t : null;
};
const sessionValue = (t: string) => createHmac("sha256", t).update("foodies-admin-session").digest("hex");

export const adminConfigured = () => token() !== null;
export const checkAdminPassword = (p: string) => {
  const t = token();
  return t !== null && safeEqual(p, t);
};
export const sessionCookie = () => ({
  name: ADMIN_COOKIE,
  value: sessionValue(token()!),
  httpOnly: true,
  sameSite: "strict" as const,
  secure: process.env.NODE_ENV === "production",
  path: "/",
  maxAge: 60 * 60 * 24 * 7,
});

export function isAdmin(req: Request) {
  const t = token();
  if (!t) return false;
  const header = req.headers.get("x-admin-token");
  if (header && safeEqual(header, t)) return true;
  const m = (req.headers.get("cookie") ?? "").match(new RegExp(`(?:^|;\\s*)${ADMIN_COOKIE}=([^;]+)`));
  return !!m && safeEqual(m[1], sessionValue(t));
}

/** For server components (admin layout). */
export async function isAdminSession() {
  const t = token();
  const c = (await cookies()).get(ADMIN_COOKIE)?.value;
  return !!t && !!c && safeEqual(c, sessionValue(t));
}

/** Runs `fn`, returns its result as JSON, and maps AppError to the right HTTP status. */
export async function respond(fn: () => Promise<unknown>) {
  try {
    return NextResponse.json(await fn());
  } catch (e) {
    if (e instanceof AppError) return NextResponse.json({ error: e.message }, { status: e.status });
    console.error(e);
    return NextResponse.json({ error: "Something went wrong" }, { status: 500 });
  }
}

export async function guard(req: Request, fn: () => Promise<unknown>) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return respond(fn);
}

export async function jsonBody(req: Request): Promise<unknown> {
  return req.json().catch(() => null);
}
