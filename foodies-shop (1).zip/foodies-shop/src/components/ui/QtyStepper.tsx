"use client";
import { Minus, Plus } from "lucide-react";
import { MAX_QTY } from "@/lib/schemas";

export default function QtyStepper({ value, onChange, label, max = MAX_QTY }: { value: number; onChange: (n: number) => void; label: string; max?: number }) {
  const btn = "grid size-8 place-items-center hover:text-brand disabled:opacity-40 disabled:hover:text-inherit";
  return (
    <div className="flex items-center border border-white/25" role="group" aria-label={`Quantity of ${label}`}>
      <button aria-label="Decrease quantity" disabled={value <= 1} onClick={() => onChange(value - 1)} className={btn}><Minus className="size-4" /></button>
      <span className="w-8 text-center text-sm" aria-live="polite">{value}</span>
      <button aria-label="Increase quantity" disabled={value >= max} onClick={() => onChange(value + 1)} className={btn}><Plus className="size-4" /></button>
    </div>
  );
}
