"use client";
import { useEffect } from "react";
import { X } from "lucide-react";

type Props = { open: boolean; onClose: () => void; title: string; className?: string; children: React.ReactNode };

export default function Drawer({ open, onClose, title, className = "", children }: Props) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  return (
    <div className={`fixed inset-0 z-[1000] ${open ? "" : "pointer-events-none"}`}>
      <div onClick={onClose} className={`absolute inset-0 bg-black/60 transition-opacity ${open ? "opacity-100" : "opacity-0"}`} />
      <aside
        inert={!open}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`absolute right-0 top-0 flex h-full w-[min(100%,380px)] flex-col transition-transform duration-300 ${open ? "translate-x-0" : "translate-x-full"} ${className}`}
      >
        <div className="flex h-[70px] shrink-0 items-center justify-between bg-maroon px-5">
          <h2 className="text-xl tracking-wide">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="hover:text-brand"><X /></button>
        </div>
        {children}
      </aside>
    </div>
  );
}
