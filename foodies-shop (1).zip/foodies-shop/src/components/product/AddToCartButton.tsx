"use client";
import type { Product } from "@/types";
import { useCart } from "@/store/cart";
import { useUI } from "@/store/ui";

export default function AddToCartButton({ product, qty = 1, disabled = false }: { product: Product; qty?: number; disabled?: boolean }) {
  const add = useCart((s) => s.add);
  const set = useUI((s) => s.set);
  if (disabled) return <button disabled className="h-11 w-full cursor-not-allowed rounded-[5px] bg-white/20 text-sm font-bold text-white/60">OUT OF STOCK</button>;
  return (
    <button
      onClick={() => { add(product, qty); set({ cartOpen: true }); }}
      className="h-11 w-full rounded-[5px] bg-brand text-sm font-bold transition-colors hover:bg-red-700"
    >
      ADD TO CART
    </button>
  );
}
