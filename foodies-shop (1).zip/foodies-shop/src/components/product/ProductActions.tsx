"use client";
import { useState } from "react";
import type { Product } from "@/types";
import { MAX_QTY } from "@/lib/schemas";
import QtyStepper from "@/components/ui/QtyStepper";
import AddToCartButton from "./AddToCartButton";

export default function ProductActions({ product }: { product: Product }) {
  const max = Math.min(MAX_QTY, product.stock ?? MAX_QTY);
  const [qty, setQty] = useState(1);
  const soldOut = max < 1;
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-4">
        {!soldOut && <QtyStepper value={qty} max={max} onChange={setQty} label={product.name} />}
        <div className="min-w-[200px] flex-1"><AddToCartButton product={product} qty={qty} disabled={soldOut} /></div>
      </div>
      {product.stock !== null && product.stock > 0 && product.stock <= 5 && <p className="text-sm text-amber-300">Only {product.stock} left</p>}
    </div>
  );
}
