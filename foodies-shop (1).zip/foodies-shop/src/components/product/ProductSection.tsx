import Link from "next/link";
import type { Product } from "@/types";
import ProductGrid from "./ProductGrid";

type Props = { title: string; products: Product[]; href?: string; size?: "lg" | "md" };

export default function ProductSection({ title, products, href, size = "md" }: Props) {
  if (products.length === 0) return null;
  return (
    <section className="mx-auto max-w-[1366px] px-4 pb-12">
      <h2 className={`py-12 text-center ${size === "lg" ? "pt-[70px] text-4xl" : "text-2xl"}`}>{title}</h2>
      <ProductGrid products={products} />
      {href && (
        <div className="mt-8 text-center">
          <Link href={href} className="border-b border-brand pb-0.5 text-sm uppercase hover:text-brand">View all</Link>
        </div>
      )}
    </section>
  );
}
