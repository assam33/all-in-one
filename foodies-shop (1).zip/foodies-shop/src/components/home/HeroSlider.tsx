"use client";
import Image from "next/image";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";
import type { HeroSlide } from "@/types";

export default function HeroSlider({ slides }: { slides: HeroSlide[] }) {
  if (slides.length === 0) return null;
  const many = slides.length > 1;
  return (
    <section aria-label="Promotions">
      <Swiper
        modules={[Autoplay, Pagination]}
        autoplay={many ? { delay: 3000, disableOnInteraction: false } : false}
        pagination={{ clickable: true }}
        loop={many}
        style={{ "--swiper-theme-color": "#ff0000" } as React.CSSProperties}
        className="h-[220px] sm:h-[380px] lg:h-[568px]"
      >
        {slides.map((s, i) => (
          <SwiperSlide key={s.id}>
            <Image src={s.src} alt={s.alt} fill sizes="100vw" priority={i === 0} className="object-cover" />
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
}
