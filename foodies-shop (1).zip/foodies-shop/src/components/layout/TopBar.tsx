import { site } from "@/data/site";

export default function TopBar() {
  return (
    <div className="bg-brand py-1.5 text-center">
      <div className="mx-auto max-w-[1366px] px-4">
        <p className="text-[15px] md:text-base">{site.announcement}</p>
        <ul className="hidden justify-between text-xs md:flex lg:text-sm">
          {site.timings.map((t) => <li key={t}>{t}</li>)}
        </ul>
      </div>
    </div>
  );
}
