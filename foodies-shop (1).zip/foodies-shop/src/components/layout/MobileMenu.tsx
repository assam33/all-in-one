"use client";
import Link from "next/link";
import { ChevronDown } from "lucide-react";
import { useCatalog } from "@/components/CatalogProvider";
import { useUI } from "@/store/ui";
import Drawer from "@/components/ui/Drawer";

export default function MobileMenu() {
  const { menuOpen, set } = useUI();
  const { categories } = useCatalog();
  const close = () => set({ menuOpen: false });
  const row = "block px-5 py-4 uppercase hover:text-brand";

  return (
    <Drawer open={menuOpen} onClose={close} title="MENU" className="bg-ink">
      <nav className="flex-1 overflow-y-auto">
        <ul>
          {categories.map((c) => (
            <li key={c.slug} className="border-b border-white/10">
              {c.children ? (
                <details>
                  <summary className={`${row} flex cursor-pointer list-none items-center justify-between [&::-webkit-details-marker]:hidden`}>
                    {c.label} <ChevronDown className="size-4" />
                  </summary>
                  <ul className="bg-panel pb-2 text-sm">
                    <li><Link href={`/category/${c.slug}`} onClick={close} className="block px-8 py-2 text-brand">View all {c.label}</Link></li>
                    {c.children.map((k) => (
                      <li key={k.slug}><Link href={`/category/${k.slug}`} onClick={close} className="block px-8 py-2 hover:text-brand">{k.label}</Link></li>
                    ))}
                  </ul>
                </details>
              ) : (
                <Link href={`/category/${c.slug}`} onClick={close} className={row}>{c.label}</Link>
              )}
            </li>
          ))}
        </ul>
      </nav>
    </Drawer>
  );
}
