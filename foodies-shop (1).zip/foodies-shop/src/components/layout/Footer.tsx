import Image from "next/image";
import Link from "next/link";
import { MapPin } from "lucide-react";
import { site } from "@/data/site";

const Facebook = () => (
  <svg viewBox="0 0 24 24" className="size-5" fill="currentColor" aria-hidden>
    <path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.44 2.89h-2.34v6.99A10 10 0 0 0 22 12z" />
  </svg>
);
const Instagram = () => (
  <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r=".5" fill="currentColor" />
  </svg>
);

const muted = "text-sm text-white/70 hover:text-brand";
const LinkList = ({ title, links }: { title: string; links: { label: string; href: string }[] }) => (
  <div>
    <h3 className="mb-4 text-lg">{title}</h3>
    <ul className="flex flex-col gap-3.5">
      {links.map((l) => <li key={l.label}><Link href={l.href} className={muted}>{l.label}</Link></li>)}
    </ul>
  </div>
);

export default function Footer() {
  const { contact, social } = site;
  return (
    <footer className="mt-16 bg-panel">
      <div className="mx-auto grid max-w-[1366px] gap-10 px-5 py-12 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div className="flex flex-col gap-4">
          <Link href="/"><Image src="/images/brand/logo.png" alt={site.company} width={65} height={81} className="h-[81px] w-auto" /></Link>
          <p className="max-w-sm text-sm text-white/70">{site.about}</p>
          <div className="flex gap-2">
            <a href={social.facebook} target="_blank" rel="noreferrer" aria-label="Facebook" className="grid size-10 place-items-center rounded-full border border-white/60 hover:text-brand"><Facebook /></a>
            <a href={social.instagram} target="_blank" rel="noreferrer" aria-label="Instagram" className="grid size-10 place-items-center rounded-full border border-white/60 hover:text-brand"><Instagram /></a>
          </div>
          <p className="flex items-center gap-2 text-sm"><MapPin className="size-4" />{site.location}</p>
        </div>

        <LinkList title="Site Links" links={site.footerLinks.site} />
        <LinkList title="Useful Links" links={site.footerLinks.useful} />

        <div>
          <h3 className="mb-4 text-lg">Contact Us</h3>
          <ul className="flex flex-col gap-3.5 text-sm text-white/70">
            <li className="text-base text-white">Customer support | queries</li>
            <li><a href={`tel:${contact.supportPhone}`} className="hover:text-brand">Ph#: {contact.supportPhone}</a></li>
            <li className="pt-2 text-base text-white">For complaints only</li>
            <li><a href={`tel:${contact.complaintPhone}`} className="hover:text-brand">Ph#: {contact.complaintPhone}</a></li>
            <li>UAN: {contact.uan}</li>
            <li><a href={`mailto:${contact.email}`} className="break-all hover:text-brand">{contact.email}</a></li>
          </ul>
        </div>
      </div>
      <p className="border-t border-white/10 py-4 text-center text-xs text-white/50">
        © {new Date().getFullYear()} {site.company}. All rights reserved.
      </p>
    </footer>
  );
}
