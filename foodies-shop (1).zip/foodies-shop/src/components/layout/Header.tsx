"use client";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { MapPin, Menu, Search, ShoppingCart, User } from "lucide-react";
import { site } from "@/data/site";
import { useUI } from "@/store/ui";
import { useCartView } from "@/store/useCartView";

function SearchBar({ onDone }: { onDone: () => void }) {
  const router = useRouter();
  const [q, setQ] = useState("");
  function submit(e: FormEvent) {
    e.preventDefault();
    if (!q.trim()) return;
    router.push(`/search?q=${encodeURIComponent(q.trim())}`);
    onDone();
  }
  return (
    <form onSubmit={submit} role="search" className="mx-auto flex max-w-[1366px] gap-2 px-4 pb-4">
      <input
        autoFocus
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search burgers, pizza, soup..."
        className="min-w-0 flex-1 rounded-md border border-white/20 bg-panel px-4 py-2.5 outline-none focus:border-brand"
      />
      <button className="rounded-md bg-brand px-6 font-bold">SEARCH</button>
    </form>
  );
}

export default function Header() {
  const { count } = useCartView();
  const { searchOpen, set } = useUI();

  return (
    <header>
      <div className="mx-auto flex h-[90px] max-w-[1366px] items-center justify-between px-4 md:grid md:grid-cols-3">
        <div className="hidden items-center gap-2 md:flex">
          <MapPin className="size-6" />
          <span className="text-sm">{site.location}</span>
        </div>

        <Link href="/" aria-label={`${site.company} home`} className="md:justify-self-center">
          <Image src="/images/brand/logo.png" alt={site.company} width={40} height={50} priority className="h-[50px] w-auto" />
        </Link>

        <ul className="flex items-center gap-5 md:justify-self-end">
          <li><button aria-label="Search" onClick={() => set({ searchOpen: !searchOpen })} className="hover:text-brand"><Search /></button></li>
          <li><Link href="/account" aria-label="Account and order tracking" className="hover:text-brand"><User /></Link></li>
          <li>
            <button aria-label="Open cart" onClick={() => set({ cartOpen: true })} className="relative hover:text-brand">
              <ShoppingCart />
              {count > 0 && (
                <span className="absolute -right-2 -top-2 grid size-5 place-items-center rounded-full bg-brand text-[11px] text-white">{count}</span>
              )}
            </button>
          </li>
          <li className="md:hidden"><button aria-label="Open menu" onClick={() => set({ menuOpen: true })} className="hover:text-brand"><Menu /></button></li>
        </ul>
      </div>
      {searchOpen && <SearchBar onDone={() => set({ searchOpen: false })} />}
    </header>
  );
}
