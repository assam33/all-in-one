"use client";
import { createContext, useContext, useMemo } from "react";
import type { Category } from "@/types";

// Public catalogue snapshot from the server layout (menu + cart prices/stock limits).
export type CatalogProduct = { slug: string; name: string; price: number; image: string; stock: number | null };
type Value = { categories: Category[]; products: Record<string, CatalogProduct> };

const Ctx = createContext<Value>({ categories: [], products: {} });
export const useCatalog = () => useContext(Ctx);

export default function CatalogProvider({ categories, products, children }: { categories: Category[]; products: CatalogProduct[]; children: React.ReactNode }) {
  const value = useMemo(() => ({ categories, products: Object.fromEntries(products.map((p) => [p.slug, p])) }), [categories, products]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
