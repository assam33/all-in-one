"use client";
import { useCallback, useEffect, useState, type ChangeEvent } from "react";
import type { PosLogEntry } from "@/types";
import { api, btn, btnGhost, msg, post } from "./api";

type Status = { posLog: PosLogEntry[]; inboundKeySet: boolean; webhookSet: boolean; products: number; withSku: number };
const code = "block overflow-x-auto whitespace-pre rounded-md bg-ink p-3 text-xs text-white/80";
const Badge = ({ ok, on, off }: { ok: boolean; on: string; off: string }) => (
  <span className={`rounded-full px-3 py-0.5 text-xs font-bold ${ok ? "bg-green-600" : "bg-amber-600"}`}>{ok ? on : off}</span>
);

export default function PosAdmin() {
  const [s, setS] = useState<Status | null>(null);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [origin, setOrigin] = useState("https://YOUR-SITE");

  const load = useCallback(async () => {
    try { setS(await api<Status>("/api/admin/pos")); } catch (e) { setError(msg(e)); }
  }, []);
  useEffect(() => { setOrigin(window.location.origin); void load(); }, [load]);

  async function testHook() {
    setError(""); setNote("");
    try {
      const r = await post<{ ok: boolean; error?: string; attempts: number }>("/api/admin/pos", { action: "test_webhook" });
      r.ok ? setNote("Your POS accepted the test event.") : setError(`POS webhook failed: ${r.error}`);
    } catch (e) { setError(msg(e)); }
  }

  async function importCsv(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setError(""); setNote("");
    try {
      const r = await post<{ created: number; updated: number; errors: string[] }>("/api/admin/pos", { action: "import", csv: await file.text() });
      setNote(`Import done: ${r.updated} updated, ${r.created} created${r.errors.length ? `, ${r.errors.length} rows skipped (see log)` : ""}.`);
      await load();
    } catch (err) { setError(msg(err)); }
  }

  if (!s) return <p className="text-white/60">{error || "Loading..."}</p>;
  return (
    <div className="space-y-10 text-sm">
      {error && <p role="alert" className="rounded-md bg-red-500/15 px-4 py-3 text-red-300">{error}</p>}
      {note && <p className="rounded-md bg-green-600/20 px-4 py-3 text-green-300">{note}</p>}

      <section className="space-y-3">
        <h2 className="text-xl">1. POS → Website (stock, price, new items)</h2>
        <p>Status: <Badge ok={s.inboundKeySet} on="API key set" off="POS_API_KEY not set (16+ characters)" /> · {s.withSku} of {s.products} products have a SKU.</p>
        <p className="text-white/70">Your POS (or its developer / a connector like Zapier or n8n) calls these endpoints with the header <code>Authorization: Bearer POS_API_KEY</code>. Products are matched by <b>SKU</b>, so give every product the same SKU in the POS and here. The POS is the source of truth for stock and price.</p>
        <code className={code}>{`# update price / stock (new items are created hidden until you add a photo)
curl -X PUT ${origin}/api/pos/products \\
  -H "Authorization: Bearer POS_API_KEY" -H "Content-Type: application/json" \\
  -d '{"products":[{"sku":"BRG-01","price":499,"stock":25},{"sku":"BRG-02","stock":0,"active":false}]}'

# read the website catalogue
curl ${origin}/api/pos/products -H "Authorization: Bearer POS_API_KEY"`}</code>
      </section>

      <section className="space-y-3">
        <h2 className="text-xl">2. Website → POS (online orders)</h2>
        <p>Webhook: <Badge ok={s.webhookSet} on="POS_WEBHOOK_URL set" off="POS_WEBHOOK_URL not set" /></p>
        <p className="text-white/70">When an order is confirmed (or cancelled) we POST it to your POS, signed with <code>X-Signature: sha256=HMAC(body, POS_WEBHOOK_SECRET)</code>, retrying 3 times. If your POS cannot receive webhooks, let it <b>pull</b> instead:</p>
        <code className={code}>{`curl ${origin}/api/pos/orders -H "Authorization: Bearer POS_API_KEY"          # confirmed, not yet acknowledged
curl -X POST ${origin}/api/pos/orders/JI-XXXXXXXX/ack -H "Authorization: Bearer POS_API_KEY"   # mark as imported`}</code>
        <button onClick={testHook} disabled={!s.webhookSet} className={btnGhost}>SEND TEST EVENT TO POS</button>
      </section>

      <section className="space-y-3">
        <h2 className="text-xl">3. No API? Use CSV</h2>
        <p className="text-white/70">Export your product list, or import a file exported from the POS. Columns: <code>sku,name,price,stock,category,active</code> (stock empty = unchanged, <code>untracked</code> = don&apos;t track).</p>
        <div className="flex flex-wrap items-center gap-3">
          <a href="/api/admin/export" className={btn}>DOWNLOAD products.csv</a>
          <label className={`${btnGhost} cursor-pointer`}>IMPORT CSV<input type="file" accept=".csv,text/csv" onChange={importCsv} className="hidden" /></label>
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-xl">Recent syncs</h2>
        {s.posLog.length === 0 ? <p className="text-white/60">Nothing synced yet.</p> : (
          <ul className="space-y-2">
            {s.posLog.map((l) => (
              <li key={l.at} className="rounded-md bg-panel px-4 py-2">
                {new Date(l.at).toLocaleString("en-GB")} · {l.source.toUpperCase()} · {l.updated} updated, {l.created} created
                {l.errors.length > 0 && <ul className="mt-1 list-disc pl-5 text-amber-300">{l.errors.map((e) => <li key={e}>{e}</li>)}</ul>}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
