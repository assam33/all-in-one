"use client";
import { useCallback, useEffect, useState } from "react";
import type { Order } from "@/types";
import { formatPrice } from "@/lib/format";
import { methodInfo, paymentStatusLabel } from "@/lib/payments/methods";
import { api, msg, post } from "./api";

type Action = "mark_paid" | "reject_payment" | "cancel" | "resend_pos";

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try { setOrders((await api<{ orders: Order[] }>("/api/admin/orders")).orders); } catch (e) { setError(msg(e)); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function act(id: string, action: Action) {
    if (action === "cancel" && !window.confirm(`Cancel order ${id}? Its items go back into stock.`)) return;
    setError("");
    try { await post(`/api/admin/orders/${id}`, { action }); } catch (e) { setError(msg(e)); }
    await load();
  }

  const btn = "rounded px-3 py-1 text-xs font-bold";
  return (
    <div>
      {error && <p className="mb-4 text-red-400">{error}</p>}
      {orders?.length === 0 && <p className="text-white/70">No orders yet.</p>}
      <ul className="space-y-4">
        {orders?.map((o) => (
          <li key={o.id} className="rounded-md bg-panel p-4 text-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <strong className="text-base">{o.id}</strong>
              <span className="text-white/60">{new Date(o.createdAt).toLocaleString("en-GB")}</span>
              <span className="rounded-full bg-white/15 px-3 py-0.5 text-xs uppercase">{o.status.replace("_", " ")}</span>
            </div>
            <p className="mt-2">{o.customer.name} · {o.customer.phone}</p>
            <p className="text-white/70">{o.customer.address}</p>
            {o.customer.notes && <p className="text-white/70">Note: {o.customer.notes}</p>}
            <p className="mt-2">{o.items.map((i) => `${i.name} × ${i.qty}`).join(", ")}</p>
            <p className="mt-2 font-bold">{formatPrice(o.total)} — {methodInfo[o.paymentMethod].label} — {paymentStatusLabel(o)}</p>
            {o.paymentRef && <p className="text-amber-300">Transaction ID: {o.paymentRef}</p>}
            {o.posSync && <p className={o.posSync.status === "failed" ? "text-red-400" : "text-white/60"}>POS: {o.posSync.acked ? "imported by POS" : o.posSync.status}{o.posSync.error ? ` (${o.posSync.error})` : ""}</p>}
            {o.status !== "cancelled" && (
              <div className="mt-3 flex flex-wrap gap-2">
                {o.paymentStatus !== "paid" && <button onClick={() => act(o.id, "mark_paid")} className={`${btn} bg-green-600`}>MARK PAID</button>}
                {o.paymentStatus === "awaiting_verification" && <button onClick={() => act(o.id, "reject_payment")} className={`${btn} bg-amber-600`}>REJECT PAYMENT</button>}
                {o.status === "received" && o.posSync?.status !== "sent" && <button onClick={() => act(o.id, "resend_pos")} className={`${btn} border border-white/30`}>SEND TO POS</button>}
                <button onClick={() => act(o.id, "cancel")} className={`${btn} border border-white/30`}>CANCEL ORDER</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
