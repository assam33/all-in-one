"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { post } from "./api";

const links = [
  { href: "/admin", label: "Orders" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/media", label: "Images & Video" },
  { href: "/admin/pos", label: "POS & Inventory" },
];

export default function AdminNav() {
  const path = usePathname();
  const router = useRouter();
  return (
    <nav className="border-b border-white/15 bg-panel">
      <ul className="mx-auto flex max-w-[1100px] flex-wrap items-center gap-1 px-4 py-2 text-sm">
        {links.map((l) => (
          <li key={l.href}>
            <Link href={l.href} className={`block rounded-md px-3 py-2 ${path === l.href ? "bg-brand font-bold" : "hover:text-brand"}`}>{l.label}</Link>
          </li>
        ))}
        <li className="ml-auto">
          <button onClick={async () => { await post("/api/admin/logout", {}); router.refresh(); }} className="px-3 py-2 text-white/60 hover:text-brand">Log out</button>
        </li>
      </ul>
    </nav>
  );
}
