"use client";
import { useEffect, useState } from "react";
import type { Media } from "@/types";
import { api, btn, btnGhost, field, msg, post } from "./api";
import Uploader from "./Uploader";

export default function MediaAdmin() {
  const [media, setMedia] = useState<Media | null>(null);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    api<{ media: Media }>("/api/admin/media").then((d) => setMedia(d.media)).catch((e) => setError(msg(e)));
  }, []);
  if (!media) return <p className="text-white/60">{error || "Loading..."}</p>;

  const change = (m: Media) => { setMedia(m); setSaved(false); };
  const slides = media.heroSlides;
  const move = (i: number, d: number) => {
    const next = [...slides];
    [next[i], next[i + d]] = [next[i + d], next[i]];
    change({ ...media, heroSlides: next });
  };

  async function save() {
    setError("");
    try { await post("/api/admin/media", media); setSaved(true); } catch (e) { setError(msg(e)); }
  }

  return (
    <div className="space-y-10">
      <section>
        <h2 className="mb-1 text-xl">Home page slider images</h2>
        <p className="mb-4 text-sm text-white/60">Wide images look best (about 1920×800). Order = order on the site.</p>
        <ul className="space-y-3">
          {slides.map((s, i) => (
            <li key={s.id} className="flex flex-wrap items-center gap-4 rounded-md bg-panel p-3">
              <img src={s.src} alt="" className="h-20 w-40 rounded-md object-cover" />
              <input value={s.alt} onChange={(e) => change({ ...media, heroSlides: slides.map((x) => (x.id === s.id ? { ...x, alt: e.target.value } : x)) })} placeholder="Short description (alt text)" className={`${field} min-w-[180px] flex-1`} />
              <div className="flex gap-2">
                <button disabled={i === 0} onClick={() => move(i, -1)} className={btnGhost} aria-label="Move up">↑</button>
                <button disabled={i === slides.length - 1} onClick={() => move(i, 1)} className={btnGhost} aria-label="Move down">↓</button>
                <button onClick={() => change({ ...media, heroSlides: slides.filter((x) => x.id !== s.id) })} className={btnGhost}>REMOVE</button>
              </div>
            </li>
          ))}
        </ul>
        <div className="mt-4 max-w-sm">
          <p className="mb-2 text-sm">Add a slide</p>
          <Uploader value="" onChange={(src) => change({ ...media, heroSlides: [...slides, { id: `s-${Date.now().toString(36)}`, src, alt: "Promotion" }] })} />
        </div>
      </section>

      <section>
        <h2 className="mb-4 text-xl">Promo video section</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div><p className="mb-2 text-sm">Video</p><Uploader kind="video" value={media.promo.src} onChange={(src) => change({ ...media, promo: { ...media.promo, src } })} />
            {media.promo.src && <button onClick={() => change({ ...media, promo: { ...media.promo, src: "" } })} className={`${btnGhost} mt-2`}>REMOVE VIDEO (hides the section)</button>}
          </div>
          <div className="space-y-3">
            <label className="block text-sm">Heading<input value={media.promo.heading} onChange={(e) => change({ ...media, promo: { ...media.promo, heading: e.target.value } })} className={field} /></label>
            <label className="block text-sm">Text<textarea rows={4} value={media.promo.text} onChange={(e) => change({ ...media, promo: { ...media.promo, text: e.target.value } })} className={field} /></label>
          </div>
        </div>
      </section>

      {error && <p className="text-red-400">{error}</p>}
      <div className="flex items-center gap-4">
        <button onClick={save} className={btn}>SAVE CHANGES</button>
        {saved && <span className="text-green-400">Saved. The home page is updated.</span>}
      </div>
    </div>
  );
}
