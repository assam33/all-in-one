"use client";
import { useState, type ChangeEvent } from "react";
import { msg, upload } from "./api";

type Props = { value: string; onChange: (url: string) => void; kind?: "image" | "video" };

export default function Uploader({ value, onChange, kind = "image" }: Props) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function pick(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      onChange(await upload(file, kind));
    } catch (err) {
      setError(msg(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-2">
      {value && (kind === "image"
        ? <img src={value} alt="Preview" className="h-28 w-28 rounded-md object-cover" />
        : <video src={value} controls muted className="h-36 rounded-md" />)}
      <input
        type="file"
        onChange={pick}
        accept={kind === "image" ? "image/jpeg,image/png,image/webp,image/avif,image/gif" : "video/mp4,video/webm"}
        className="block w-full text-sm file:mr-3 file:rounded-md file:border-0 file:bg-white/15 file:px-3 file:py-2 file:text-white"
      />
      <p className="text-xs text-white/50">{kind === "image" ? "JPG, PNG, WebP, AVIF or GIF up to 8 MB" : "MP4 or WebM up to 60 MB"}</p>
      {busy && <p className="text-sm text-amber-300">Uploading...</p>}
      {error && <p className="text-sm text-red-400">{error}</p>}
    </div>
  );
}
