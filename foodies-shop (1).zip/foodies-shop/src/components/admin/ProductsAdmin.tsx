"use client";
import { useCallback, useEffect, useState, type FormEvent } from "react";
import type { CategoryRecord, Product } from "@/types";
import { formatPrice } from "@/lib/format";
import { api, btn, btnGhost, field, msg, post } from "./api";
import Uploader from "./Uploader";

const toBody = (p: Product, patch: Partial<Product> = {}) => ({ ...p, ...patch });

export default function ProductsAdmin() {
  const [products, setProducts] = useState<Product[]>([]);
  const [cats, setCats] = useState<CategoryRecord[]>([]);
  const [editing, setEditing] = useState<Product | "new" | null>(null);
  const [image, setImage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState("");

  const load = useCallback(async () => {
    try {
      const d = await api<{ products: Product[]; categories: CategoryRecord[] }>("/api/admin/products");
      setProducts(d.products);
      setCats(d.categories);
    } catch (e) {
      setError(msg(e));
    }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const catLabel = (slug: string) => cats.find((c) => c.slug === slug)?.label ?? slug;
  const open = (p: Product | "new") => { setEditing(p); setImage(p === "new" ? "" : p.image); setError(""); };

  async function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const text = (k: string) => String(fd.get(k) ?? "").trim();
    const stock = text("stock");
    setBusy(true);
    setError("");
    try {
      await post("/api/admin/products", {
        slug: editing && editing !== "new" ? editing.slug : undefined,
        name: text("name"), sku: text("sku") || undefined, price: text("price") === "" ? undefined : Number(text("price")),
        category: text("category"), description: text("description") || undefined, image,
        active: fd.get("active") === "on", stock: stock === "" ? null : Number(stock),
      });
      setEditing(null);
      await load();
    } catch (err) {
      setError(msg(err));
    } finally {
      setBusy(false);
    }
  }

  async function quick(p: Product, patch: Partial<Product>) {
    try { await post("/api/admin/products", toBody(p, patch)); await load(); } catch (e) { setError(msg(e)); }
  }
  async function remove(p: Product) {
    if (!window.confirm(`Delete "${p.name}"? This cannot be undone.`)) return;
    try { await api(`/api/admin/products/${p.slug}`, { method: "DELETE" }); await load(); } catch (e) { setError(msg(e)); }
  }

  const shown = products.filter((p) => !q || `${p.name} ${p.sku ?? ""}`.toLowerCase().includes(q.toLowerCase()));
  const tops = cats.filter((c) => !c.parent);
  const cur = editing && editing !== "new" ? editing : undefined;

  return (
    <div>
      <div className="mb-6 flex flex-wrap gap-3">
        <button onClick={() => open("new")} className={btn}>+ ADD PRODUCT</button>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or SKU" className={`${field} max-w-xs`} />
      </div>
      {error && !editing && <p className="mb-4 text-red-400">{error}</p>}

      {editing && (
        <form key={cur?.slug ?? "new"} onSubmit={save} className="mb-8 grid gap-4 rounded-md bg-panel p-5 md:grid-cols-2">
          <h2 className="text-xl md:col-span-2">{cur ? `Edit: ${cur.name}` : "New product"}</h2>
          <label className="block text-sm">Name *<input name="name" defaultValue={cur?.name} className={field} /></label>
          <label className="block text-sm">SKU (same code as in your POS)<input name="sku" defaultValue={cur?.sku} className={field} /></label>
          <label className="block text-sm">Price *<input name="price" type="number" min="0" step="any" defaultValue={cur?.price} className={field} /></label>
          <label className="block text-sm">Stock (leave empty = not tracked)<input name="stock" type="number" min="0" step="1" defaultValue={cur?.stock ?? ""} className={field} /></label>
          <label className="block text-sm">Category *
            <select name="category" defaultValue={cur?.category ?? ""} className={field}>
              <option value="" disabled>Choose...</option>
              {tops.map((t) => {
                const kids = cats.filter((k) => k.parent === t.slug);
                return kids.length ? (
                  <optgroup key={t.slug} label={t.label}>
                    <option value={t.slug}>{t.label} (general)</option>
                    {kids.map((k) => <option key={k.slug} value={k.slug}>{k.label}</option>)}
                  </optgroup>
                ) : <option key={t.slug} value={t.slug}>{t.label}</option>;
              })}
            </select>
          </label>
          <label className="flex items-center gap-2 self-end pb-2 text-sm"><input name="active" type="checkbox" defaultChecked={cur?.active ?? true} className="size-4 accent-[#ff0000]" /> Visible in the shop</label>
          <label className="block text-sm md:col-span-2">Description (optional)<textarea name="description" rows={2} defaultValue={cur?.description} className={field} /></label>
          <div className="md:col-span-2"><p className="mb-2 text-sm">Product image *</p><Uploader value={image} onChange={setImage} /></div>
          {error && <p className="text-red-400 md:col-span-2">{error}</p>}
          <div className="flex gap-3 md:col-span-2">
            <button disabled={busy} className={btn}>{busy ? "SAVING..." : "SAVE PRODUCT"}</button>
            <button type="button" onClick={() => setEditing(null)} className={btnGhost}>CANCEL</button>
          </div>
        </form>
      )}

      <ul className="space-y-3">
        {shown.map((p) => (
          <li key={p.slug} className="flex flex-wrap items-center gap-4 rounded-md bg-panel p-3 text-sm">
            <img src={p.image} alt="" className="size-16 rounded-md object-cover" />
            <div className="min-w-[180px] flex-1">
              <p className="font-bold">{p.name}</p>
              <p className="text-white/60">{catLabel(p.category)}{p.sku ? ` · SKU ${p.sku}` : ""}</p>
            </div>
            <span>{formatPrice(p.price)}</span>
            <span className={p.stock !== null && p.stock <= 0 ? "text-red-400" : "text-white/70"}>{p.stock === null ? "Stock: not tracked" : `Stock: ${p.stock}`}</span>
            <div className="flex gap-2">
              <button onClick={() => quick(p, { active: !p.active })} className={btnGhost}>{p.active ? "HIDE" : "SHOW"}</button>
              <button onClick={() => open(p)} className={btnGhost}>EDIT</button>
              <button onClick={() => remove(p)} className={btnGhost}>DELETE</button>
            </div>
            {!p.active && <span className="w-full text-xs text-amber-300">Hidden from the shop</span>}
          </li>
        ))}
        {shown.length === 0 && <li className="text-white/60">No products found.</li>}
      </ul>
    </div>
  );
}
