"use client";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { btn, field, msg, post } from "./api";

export default function AdminLogin({ configured }: { configured: boolean }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await post("/api/admin/login", { password: String(new FormData(e.currentTarget).get("password") ?? "") });
      router.refresh();
    } catch (err) {
      setError(msg(err));
      setBusy(false);
    }
  }

  if (!configured) {
    return (
      <div className="mx-auto max-w-[520px] px-4 py-20 text-center">
        <h1 className="mb-4 text-3xl">Admin is disabled</h1>
        <p className="text-white/70">Set <code className="rounded bg-panel px-1">ADMIN_TOKEN</code> (8+ characters) in <code className="rounded bg-panel px-1">.env.local</code> and restart the server.</p>
      </div>
    );
  }
  return (
    <form onSubmit={submit} className="mx-auto max-w-[380px] space-y-4 px-4 py-20">
      <h1 className="text-center text-3xl">Admin login</h1>
      <input name="password" type="password" autoFocus placeholder="Admin password" className={field} />
      {error && <p className="text-sm text-red-400">{error}</p>}
      <button disabled={busy} className={`${btn} w-full py-3`}>{busy ? "..." : "LOG IN"}</button>
    </form>
  );
}
