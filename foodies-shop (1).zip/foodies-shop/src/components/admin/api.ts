export const msg = (e: unknown) => (e instanceof Error ? e.message : "Something went wrong");

export async function api<T = unknown>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? "Request failed");
  return data as T;
}

export const post = <T = unknown>(url: string, body: unknown) =>
  api<T>(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

export async function upload(file: File, kind: "image" | "video"): Promise<string> {
  const form = new FormData();
  form.set("file", file);
  form.set("kind", kind);
  return (await api<{ url: string }>("/api/admin/upload", { method: "POST", body: form })).url;
}

export const field = "w-full rounded-md border border-white/20 bg-ink px-3 py-2 outline-none focus:border-brand";
export const btn = "rounded-md bg-brand px-4 py-2 text-sm font-bold hover:bg-red-700 disabled:opacity-60";
export const btnGhost = "rounded-md border border-white/30 px-4 py-2 text-sm font-bold hover:border-brand hover:text-brand disabled:opacity-60";
