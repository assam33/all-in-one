"use client";
import { useCallback, useEffect, useState, type FormEvent } from "react";
import type { CategoryRecord } from "@/types";
import { api, btn, btnGhost, field, msg, post } from "./api";

export default function CategoriesAdmin() {
  const [cats, setCats] = useState<CategoryRecord[]>([]);
  const [editing, setEditing] = useState<CategoryRecord | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try { setCats((await api<{ categories: CategoryRecord[] }>("/api/admin/categories")).categories); } catch (e) { setError(msg(e)); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  async function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    setError("");
    try {
      await post("/api/admin/categories", { slug: editing?.slug, label: String(fd.get("label") ?? ""), parent: String(fd.get("parent") ?? "") || undefined });
      setEditing(null);
      form.reset();
      await load();
    } catch (err) { setError(msg(err)); }
  }
  async function remove(c: CategoryRecord) {
    if (!window.confirm(`Delete category "${c.label}"?`)) return;
    setError("");
    try { await api(`/api/admin/categories/${c.slug}`, { method: "DELETE" }); await load(); } catch (e) { setError(msg(e)); }
  }

  const tops = cats.filter((c) => !c.parent);
  const Row = ({ c, child }: { c: CategoryRecord; child?: boolean }) => (
    <li className={`flex items-center justify-between gap-3 rounded-md bg-panel px-4 py-2 text-sm ${child ? "ml-6" : ""}`}>
      <span><strong>{c.label}</strong> <span className="text-white/50">/category/{c.slug}</span></span>
      <span className="flex gap-2">
        <button onClick={() => setEditing(c)} className={btnGhost}>RENAME</button>
        <button onClick={() => remove(c)} className={btnGhost}>DELETE</button>
      </span>
    </li>
  );

  return (
    <div>
      <form key={editing?.slug ?? "new"} onSubmit={save} className="mb-8 grid gap-4 rounded-md bg-panel p-5 md:grid-cols-[1fr_1fr_auto]">
        <h2 className="text-xl md:col-span-3">{editing ? `Rename "${editing.label}"` : "Add category"}</h2>
        <label className="block text-sm">Name *<input name="label" defaultValue={editing?.label} className={field} /></label>
        <label className="block text-sm">Parent category
          <select name="parent" defaultValue={editing?.parent ?? ""} disabled={!!editing} className={field}>
            <option value="">— Top level (shows in the main menu) —</option>
            {tops.map((t) => <option key={t.slug} value={t.slug}>Under {t.label}</option>)}
          </select>
        </label>
        <div className="flex items-end gap-2">
          <button className={btn}>{editing ? "SAVE" : "ADD"}</button>
          {editing && <button type="button" onClick={() => setEditing(null)} className={btnGhost}>CANCEL</button>}
        </div>
      </form>
      {error && <p className="mb-4 text-red-400">{error}</p>}
      <ul className="space-y-2">
        {tops.map((t) => (
          <li key={t.slug}>
            <ul className="space-y-2">
              <Row c={t} />
              {cats.filter((k) => k.parent === t.slug).map((k) => <Row key={k.slug} c={k} child />)}
            </ul>
          </li>
        ))}
      </ul>
      <p className="mt-6 text-sm text-white/50">A category can only be deleted when it has no sub-categories and no products. Its URL never changes when you rename it.</p>
    </div>
  );
}
