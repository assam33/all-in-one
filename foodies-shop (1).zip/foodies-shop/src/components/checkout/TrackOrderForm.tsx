"use client";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export default function TrackOrderForm() {
  const router = useRouter();
  const [id, setId] = useState("");
  function submit(e: FormEvent) {
    e.preventDefault();
    if (id.trim()) router.push(`/order/${encodeURIComponent(id.trim())}`);
  }
  return (
    <form onSubmit={submit} className="flex gap-2">
      <input
        value={id}
        onChange={(e) => setId(e.target.value)}
        placeholder="Order ID e.g. JI-1A2B3C4D"
        className="min-w-0 flex-1 rounded-md border border-white/20 bg-panel px-4 py-3 outline-none focus:border-brand"
      />
      <button className="rounded-md bg-brand px-6 font-bold">TRACK</button>
    </form>
  );
}
