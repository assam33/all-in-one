"use client";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import type { PaymentMethod } from "@/types";
import { formatPrice } from "@/lib/format";
import { methodInfo } from "@/lib/payments/methods";
import { orderSchema } from "@/lib/schemas";
import { useCart } from "@/store/cart";
import { useCartView } from "@/store/useCartView";
import CartSummary from "@/components/cart/CartSummary";

const input = "w-full rounded-md border border-white/20 bg-panel px-4 py-3 outline-none focus:border-brand";

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm">{label}</span>
      {children}
      {error && <span className="mt-1 block text-sm text-red-400">{error}</span>}
    </label>
  );
}

export default function CheckoutForm({ methods }: { methods: PaymentMethod[] }) {
  const router = useRouter();
  const v = useCartView();
  const clear = useCart((s) => s.clear);
  const [method, setMethod] = useState<PaymentMethod>(methods[0]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [busy, setBusy] = useState(false);

  if (!v.mounted) return <div className="min-h-[40vh]" />;
  if (v.lines.length === 0) {
    return (
      <div className="py-20 text-center">
        <p className="mb-6 text-lg text-white/70">Your cart is empty.</p>
        <Link href="/" className="rounded-md bg-brand px-6 py-2.5 font-bold">CONTINUE SHOPPING</Link>
      </div>
    );
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const get = (k: string) => String(fd.get(k) ?? "");
    const parsed = orderSchema.safeParse({
      customer: { name: get("name"), phone: get("phone"), address: get("address"), notes: get("notes") || undefined },
      method,
      items: v.lines.map((l) => ({ slug: l.slug, qty: l.qty })),
    });
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const i of parsed.error.issues) errs[String(i.path[1] ?? i.path[0])] ??= i.message;
      setErrors(errs);
      return;
    }
    setErrors({});
    setFormError("");
    setBusy(true);
    try {
      const res = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(parsed.data) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not place your order");
      clear(); // the order now exists; unpaid card/transfer orders can be completed from the order page
      if (data.redirectUrl) window.location.assign(data.redirectUrl);
      else router.push(`/order/${data.id}`);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setBusy(false);
    }
  }

  const cta = method === "card" ? `PAY ${formatPrice(v.total)} BY CARD` : method === "transfer" ? "PLACE ORDER & PAY" : "PLACE ORDER";

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_400px]">
      <form onSubmit={onSubmit} noValidate className="space-y-5">
        <Field label="Full name *" error={errors.name}><input name="name" autoComplete="name" className={input} /></Field>
        <Field label="Phone number *" error={errors.phone}><input name="phone" type="tel" autoComplete="tel" className={input} /></Field>
        <Field label="Delivery address *" error={errors.address}><textarea name="address" rows={3} autoComplete="street-address" className={input} /></Field>
        <Field label="Order notes (optional)" error={errors.notes}><textarea name="notes" rows={2} className={input} /></Field>

        <fieldset className="space-y-3">
          <legend className="mb-1 text-lg">Payment method</legend>
          {methods.map((m) => (
            <label key={m} className={`flex cursor-pointer gap-3 rounded-md border p-4 transition-colors ${method === m ? "border-brand bg-brand/10" : "border-white/20 bg-panel hover:border-white/40"}`}>
              <input type="radio" name="method" value={m} checked={method === m} onChange={() => setMethod(m)} className="mt-1 accent-[#ff0000]" />
              <span>
                <span className="block font-bold">{methodInfo[m].label}</span>
                <span className="block text-sm text-white/70">{methodInfo[m].description}</span>
              </span>
            </label>
          ))}
          {errors.method && <p className="text-sm text-red-400">{errors.method}</p>}
        </fieldset>

        {errors.items && <p className="text-red-400">{errors.items}</p>}
        {formError && <p role="alert" className="rounded-md bg-red-500/15 px-4 py-3 text-red-300">{formError}</p>}
        <button disabled={busy || v.cannotCheckout} className="h-12 w-full rounded-md bg-brand font-bold disabled:opacity-60">{busy ? "PLEASE WAIT..." : cta}</button>
        {method === "card" && <p className="text-center text-xs text-white/60">You will be redirected to a secure payment page.</p>}
      </form>

      <aside className="h-fit space-y-5 rounded-md bg-panel p-5">
        <h2 className="text-xl">Order summary</h2>
        <ul className="space-y-3">
          {v.lines.map((l) => (
            <li key={l.slug} className="flex items-center gap-3 text-sm">
              <Image src={l.image} alt="" width={48} height={48} className="size-12 rounded-md object-cover" />
              <span className="flex-1">{l.name} × {l.qty}</span>
              <span>{formatPrice(l.price * l.qty)}</span>
            </li>
          ))}
        </ul>
        <CartSummary />
        <Link href="/cart" className="block text-center text-sm underline hover:text-brand">Edit cart</Link>
      </aside>
    </div>
  );
}
