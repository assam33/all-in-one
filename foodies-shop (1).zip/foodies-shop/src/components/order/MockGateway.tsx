"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function MockGateway({ orderId }: { orderId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function finish(result: "success" | "fail") {
    setBusy(true);
    await fetch("/api/payments/mock", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ orderId, result }) });
    router.push(`/order/${orderId}`);
  }

  return (
    <div className="space-y-3">
      <button disabled={busy} onClick={() => finish("success")} className="h-12 w-full rounded-md bg-green-600 font-bold disabled:opacity-60">SIMULATE SUCCESSFUL PAYMENT</button>
      <button disabled={busy} onClick={() => finish("fail")} className="h-12 w-full rounded-md border border-white/30 font-bold disabled:opacity-60">SIMULATE FAILED PAYMENT</button>
    </div>
  );
}
