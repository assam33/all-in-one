"use client";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export function TransferForm({ orderId }: { orderId: string }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const reference = String(new FormData(e.currentTarget).get("reference") ?? "");
    setBusy(true);
    setError("");
    const res = await fetch(`/api/orders/${orderId}/transfer`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reference }) });
    if (res.ok) return router.refresh();
    setError((await res.json().catch(() => ({}))).error ?? "Something went wrong");
    setBusy(false);
  }

  return (
    <form onSubmit={submit} className="mt-4 space-y-2">
      <label className="block text-sm">Transaction ID / reference number *</label>
      <div className="flex gap-2">
        <input name="reference" className="min-w-0 flex-1 rounded-md border border-white/20 bg-ink px-4 py-3 outline-none focus:border-brand" />
        <button disabled={busy} className="rounded-md bg-brand px-5 font-bold disabled:opacity-60">{busy ? "..." : "SUBMIT"}</button>
      </div>
      {error && <p className="text-sm text-red-400">{error}</p>}
    </form>
  );
}

export function RetryCardButton({ orderId, failed }: { orderId: string; failed: boolean }) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function retry() {
    setBusy(true);
    setError("");
    const res = await fetch(`/api/orders/${orderId}/pay`, { method: "POST" });
    const data = await res.json().catch(() => ({}));
    if (res.ok && data.redirectUrl) return window.location.assign(data.redirectUrl);
    setError(data.error ?? "Something went wrong");
    setBusy(false);
  }

  return (
    <div className="mt-4">
      <button onClick={retry} disabled={busy} className="rounded-md bg-brand px-6 py-3 font-bold disabled:opacity-60">{busy ? "PLEASE WAIT..." : failed ? "TRY PAYING AGAIN" : "PAY BY CARD NOW"}</button>
      {error && <p className="mt-2 text-sm text-red-400">{error}</p>}
    </div>
  );
}
