"use client";
import { site } from "@/data/site";
import { formatPrice } from "@/lib/format";
import { useCartView } from "@/store/useCartView";

export default function CartSummary() {
  const v = useCartView();
  return (
    <div>
      <dl className="space-y-1.5 text-sm">
        <div className="flex justify-between"><dt>Subtotal ({v.count} {v.count === 1 ? "item" : "items"})</dt><dd>{formatPrice(v.subtotal)}</dd></div>
        <div className="flex justify-between"><dt>Delivery</dt><dd>{v.deliveryFee ? formatPrice(v.deliveryFee) : "Free"}</dd></div>
        <div className="flex justify-between border-t border-white/20 pt-2 text-lg"><dt>Total</dt><dd>{formatPrice(v.total)}</dd></div>
      </dl>
      {v.blocked && (
        <p className="mt-3 rounded-md bg-brand/20 px-3 py-2 text-sm">Some items are unavailable or exceed the stock we have. Please fix them in your cart to continue.</p>
      )}
      {v.belowMin && (
        <p className="mt-3 rounded-md bg-brand/20 px-3 py-2 text-sm">
          Minimum order is {formatPrice(site.minOrder)}. Add {formatPrice(v.shortBy)} more to check out.
        </p>
      )}
    </div>
  );
}
