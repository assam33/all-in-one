"use client";
import Image from "next/image";
import Link from "next/link";
import { Trash2 } from "lucide-react";
import { formatPrice } from "@/lib/format";
import { useCart } from "@/store/cart";
import type { CartViewLine } from "@/store/useCartView";
import QtyStepper from "@/components/ui/QtyStepper";

type Props = { line: CartViewLine; large?: boolean; onNavigate?: () => void };

export default function CartLineItem({ line, large = false, onNavigate }: Props) {
  const setQty = useCart((s) => s.setQty);
  const remove = useCart((s) => s.remove);
  const size = large ? 96 : 64;

  return (
    <li className="flex gap-3">
      <Link href={`/product/${line.slug}`} onClick={onNavigate} className="shrink-0">
        <Image src={line.image} alt={line.name} width={size} height={size} style={{ width: size, height: size }} className={`rounded-md object-cover ${line.unavailable ? "opacity-40" : ""}`} />
      </Link>
      <div className="flex min-w-0 flex-1 flex-col gap-2">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <Link href={`/product/${line.slug}`} onClick={onNavigate} className="line-clamp-2 text-sm font-bold hover:text-brand">{line.name}</Link>
            <p className="text-xs text-white/60">{formatPrice(line.price)} each</p>
          </div>
          <button aria-label={`Remove ${line.name}`} onClick={() => remove(line.slug)} className="p-1 text-white/60 hover:text-brand"><Trash2 className="size-4" /></button>
        </div>
        {line.unavailable ? (
          <p className="text-sm text-red-400">Out of stock or no longer available. Please remove it.</p>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <QtyStepper value={line.qty} max={line.max} onChange={(n) => setQty(line.slug, n)} label={line.name} />
              <span className="font-bold">{formatPrice(line.price * line.qty)}</span>
            </div>
            {line.overStock && (
              <p className="text-sm text-red-400">
                Only {line.max} left.{" "}
                <button onClick={() => setQty(line.slug, line.max)} className="underline">Set to {line.max}</button>
              </p>
            )}
          </>
        )}
      </div>
    </li>
  );
}
