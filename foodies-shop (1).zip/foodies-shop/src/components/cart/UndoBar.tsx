"use client";
import { useCart } from "@/store/cart";

export default function UndoBar() {
  const removed = useCart((s) => s.lastRemoved);
  const undo = useCart((s) => s.undo);
  if (!removed) return null;
  return (
    <div role="status" className="flex items-center justify-between gap-3 rounded-md bg-white/10 px-3 py-2 text-sm">
      <span className="line-clamp-1">“{removed.name}” removed</span>
      <button onClick={undo} className="shrink-0 font-bold text-brand hover:underline">UNDO</button>
    </div>
  );
}
