"use client";
import Link from "next/link";
import { ShoppingBag } from "lucide-react";
import { useCart } from "@/store/cart";
import { useUI } from "@/store/ui";
import { useCartView } from "@/store/useCartView";
import Drawer from "@/components/ui/Drawer";
import CartLineItem from "./CartLineItem";
import CartSummary from "./CartSummary";
import UndoBar from "./UndoBar";

export default function CartDrawer() {
  const { cartOpen, set } = useUI();
  const clear = useCart((s) => s.clear);
  const v = useCartView();
  const close = () => set({ cartOpen: false });

  return (
    <Drawer open={cartOpen} onClose={close} title={v.count ? `CART (${v.count})` : "CART"} className="bg-[#1b1b1b]">
      {v.lines.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center">
          <ShoppingBag className="size-14 text-white/30" />
          <p className="text-lg">Your cart is empty</p>
          <p className="text-sm text-white/60">Add something delicious to get started.</p>
          <Link href="/category/deli" onClick={close} className="rounded-md bg-brand px-6 py-2.5 font-bold">BROWSE MENU</Link>
        </div>
      ) : (
        <>
          <div className="flex-1 space-y-4 overflow-y-auto p-4">
            <UndoBar />
            <ul className="space-y-5">
              {v.lines.map((l) => <CartLineItem key={l.slug} line={l} onNavigate={close} />)}
            </ul>
          </div>
          <div className="space-y-3 border-t border-white/15 bg-black/30 p-4">
            <CartSummary />
            {v.cannotCheckout ? (
              <span aria-disabled className="block rounded-md bg-white/20 py-3 text-center font-bold text-white/60">CHECKOUT</span>
            ) : (
              <Link href="/checkout" onClick={close} className="block rounded-md bg-brand py-3 text-center font-bold hover:bg-red-700">CHECKOUT</Link>
            )}
            <div className="flex justify-between text-sm">
              <Link href="/cart" onClick={close} className="underline hover:text-brand">View full cart</Link>
              <button onClick={() => window.confirm("Remove all items from your cart?") && clear()} className="text-white/60 underline hover:text-brand">Clear cart</button>
            </div>
          </div>
        </>
      )}
    </Drawer>
  );
}
