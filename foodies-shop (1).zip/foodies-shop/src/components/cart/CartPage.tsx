"use client";
import Link from "next/link";
import { ShoppingBag } from "lucide-react";
import { useCart } from "@/store/cart";
import { useCartView } from "@/store/useCartView";
import CartLineItem from "./CartLineItem";
import CartSummary from "./CartSummary";
import UndoBar from "./UndoBar";

export default function CartPage() {
  const v = useCartView();
  const clear = useCart((s) => s.clear);

  if (!v.mounted) return <div className="min-h-[40vh]" />;
  if (v.lines.length === 0) {
    return (
      <div className="flex flex-col items-center gap-4 py-20 text-center">
        <ShoppingBag className="size-16 text-white/30" />
        <p className="text-xl">Your cart is empty</p>
        <Link href="/" className="rounded-md bg-brand px-6 py-2.5 font-bold">CONTINUE SHOPPING</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
      <div className="space-y-5">
        <UndoBar />
        <ul className="space-y-6 divide-y divide-white/10 [&>li]:pt-6 [&>li:first-child]:pt-0">
          {v.lines.map((l) => <CartLineItem key={l.slug} line={l} large />)}
        </ul>
        <div className="flex flex-wrap justify-between gap-3 pt-2 text-sm">
          <Link href="/" className="underline hover:text-brand">← Continue shopping</Link>
          <button onClick={() => window.confirm("Remove all items from your cart?") && clear()} className="text-white/60 underline hover:text-brand">Clear cart</button>
        </div>
      </div>
      <aside className="h-fit space-y-4 rounded-md bg-panel p-5 lg:sticky lg:top-4">
        <h2 className="text-xl">Order summary</h2>
        <CartSummary />
        {v.cannotCheckout ? (
          <span aria-disabled className="block rounded-md bg-white/20 py-3 text-center font-bold text-white/60">PROCEED TO CHECKOUT</span>
        ) : (
          <Link href="/checkout" className="block rounded-md bg-brand py-3 text-center font-bold hover:bg-red-700">PROCEED TO CHECKOUT</Link>
        )}
      </aside>
    </div>
  );
}
