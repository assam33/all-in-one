# Foodies – Jatala Internationals online shop

Next.js 16 (App Router) + TypeScript + Tailwind CSS v4 + Zustand + Zod.

```bash
cp .env.example .env.local     # set ADMIN_TOKEN at least
npm install
npm run dev                    # http://localhost:3000   (admin: /admin)
npm run build && npm start
npm run typecheck
```

## Folder structure
```
public/images, public/videos     files shipped with the site
src/app                          routes: shop pages, /admin/*, /api/*, /uploads/[name]
src/components                   layout/ cart/ home/ product/ checkout/ order/ admin/ ui/
src/data/site.ts                 brand text, timings, contacts, payment accounts
src/data/seed.ts                 first-run categories/products/slides (then data lives in .data/catalog.json)
src/lib/catalog.ts               catalogue + stock + POS sync logic (the only file that touches catalog.json)
src/lib/orders.ts                orders, stock reservation, cancel/restock, POS notification
src/lib/pos.ts                   POS auth + outbound webhook
src/lib/uploads.ts               image/video upload + validation
src/lib/payments/                COD / transfer / card (see below)
```

## Admin panel  (`/admin`, password = `ADMIN_TOKEN`)
| Page | What you do |
|---|---|
| Orders | verify payments, mark paid, cancel (restocks), resend to POS |
| Products | add / edit / hide / delete, upload product photo, SKU, price, stock, category |
| Categories | add top-level or sub-categories (they appear in the menu instantly), rename, delete |
| Images & Video | home slider images (order, alt text) and the promo video + its text |
| POS & Inventory | connection status, copy-paste API examples, CSV import/export, sync log |

Changes go live immediately (shop pages are regenerated on save).
Stock: `empty` = not tracked, `0` = sold out (shown as SOLD OUT, cannot be ordered). Orders take stock atomically; cancelling an order puts it back.

## Linking with your POS
Products are matched by **SKU** - give each product the same SKU in the POS and in `/admin/products`.
**The POS is the source of truth for price and stock**: send absolute numbers, not "minus 1".

1. **POS → website** (`PUT /api/pos/products`, header `Authorization: Bearer POS_API_KEY`):
   ```bash
   curl -X PUT https://YOUR-SITE/api/pos/products -H "Authorization: Bearer $POS_API_KEY" -H "Content-Type: application/json" \
     -d '{"products":[{"sku":"BRG-01","price":499,"stock":25},{"sku":"BRG-02","stock":0}]}'
   ```
   Fields: `sku` (or `slug`), `name`, `price`, `stock` (number or null), `category` (slug or name), `active`.
   Unknown SKUs with name+price+category are created **hidden** - add a photo in /admin and press SHOW.
   `GET /api/pos/products` returns the catalogue.
2. **Website → POS**: set `POS_WEBHOOK_URL` (+ `POS_WEBHOOK_SECRET`). Each confirmed / cancelled order is POSTed as
   `{"event":"order.confirmed"|"order.cancelled","order":{...items with sku...}}`, header `X-Signature: sha256=<HMAC-SHA256 of the raw body>`, 3 attempts.
   Failed deliveries show in /admin → Orders ("SEND TO POS" retries).
3. **POS can't receive webhooks?** It can pull: `GET /api/pos/orders` (confirmed + not yet acknowledged) then `POST /api/pos/orders/{id}/ack`.
4. **No API at all?** Use CSV: /admin/pos → download / import (`sku,name,price,stock,category,active`).
   Most POS systems can export such a file; Zapier/n8n/Make can also call the endpoints above.

A POS-specific connector (Odoo, Loyverse, Square, Marg, a local Pakistani POS...) is just a small script/adapter that maps that POS's API to these endpoints.

## Cart & payments
Cart: drawer + `/cart`, live prices, stock limits per line, undo, unavailable items block checkout.
Payments at checkout: **Cash on delivery** (confirmed instantly), **Online transfer** (JazzCash / Easypaisa / Bank - customer submits the transaction ID, you press MARK PAID),
**Card** (Stripe Checkout hosted page; card data never touches this server). Set `site.payments.transfer.accounts` in `src/data/site.ts` to your REAL accounts.
Stripe: set `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` and add a webhook to `/api/payments/stripe/webhook` (`checkout.session.completed`, `checkout.session.expired`).
Without keys, development uses a TEST gateway (`/pay/mock/[id]`). Another gateway = a branch in `src/lib/payments/server.ts`.

## Going live - important
- Data is stored as files (`.data/`: catalog, orders, uploads). Run on a server with a **persistent disk** (VPS, Railway/Render volume) and back `.data/` up.
  Serverless hosts (Vercel) have no writable disk: replace the `jsonStore` in `catalog.ts`/`orders.ts` with a database (Postgres/Supabase) and `uploads.ts` with S3/Cloudinary.
- Orders that wait for card/transfer payment keep their stock reserved until paid or cancelled in /admin.
- Home page sections (Starters, Burgers, Pizza & Sandwich) use those category slugs in `src/app/page.tsx`.
- Bakery items in `seed.ts` are SAMPLE data. Delete `.data/catalog.json` to reset to the seed.
- Not included: customer login, payment screenshot upload, email/WhatsApp notifications, multiple admin users.
