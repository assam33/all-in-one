# Foodies – Jatala Internationals online shop

Next.js (App Router) + TypeScript + Tailwind CSS v4 + Zustand + Zod.

## Run
```bash
npm install
npm run dev        # http://localhost:3000
npm run build && npm start
npm run typecheck
```

## Folder structure
```
public/images, public/videos   static assets (kebab-case names)
src/app                        routes: / , /category/[slug], /product/[slug], /search,
                               /checkout, /order/[id], /account, /info/[slug], /api/orders
src/components                 layout/ cart/ home/ product/ checkout/ ui/
src/data                       site.ts (brand text, timings, contacts, footer links)
                               categories.ts (menu tree)   products.ts (catalogue)
src/store                      cart.ts (persisted cart), ui.ts (drawers/search state)
src/lib                        schemas.ts (zod, shared client+server), orders.ts, format.ts
```

## Everyday tasks
- **Add a product**: add an object to `src/data/products.ts` + image in `public/images/products`.
- **Add/rename a menu category**: edit `src/data/categories.ts` (pages + menus update automatically).
- **Change phone/timings/footer**: edit `src/data/site.ts`.
- **Delivery fee**: `deliveryFee` in `src/data/site.ts`.

## Orders
`POST /api/orders` validates with Zod, recalculates prices on the server and saves to `.data/orders.json`.
For production replace `src/lib/orders.ts` with a database (Prisma + Postgres / Supabase). Serverless hosts have a read-only disk.

## Notes
- Bakery items in `products.ts` are SAMPLE data (the original site only had placeholders).
- Not included yet: user login, online payments, admin panel, email/WhatsApp order notifications.
