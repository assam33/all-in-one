import { NextResponse } from "next/server";
import { createOrder } from "@/lib/orders";
import { orderSchema } from "@/lib/schemas";

export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  const parsed = orderSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid order" }, { status: 400 });
  }

  try {
    const order = await createOrder(parsed.data);
    return NextResponse.json({ id: order.id }, { status: 201 });
  } catch (err) {
    if (err instanceof Error && err.message.startsWith("Unknown product")) {
      return NextResponse.json({ error: "Some items in your cart are no longer available." }, { status: 400 });
    }
    console.error("Order failed:", err);
    return NextResponse.json({ error: "Could not place your order. Please try again." }, { status: 500 });
  }
}
