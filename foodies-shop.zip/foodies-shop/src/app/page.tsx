import HeroSlider from "@/components/home/HeroSlider";
import VideoBanner from "@/components/home/VideoBanner";
import ProductSection from "@/components/product/ProductSection";
import { getProductsIn } from "@/data/products";

export default function Home() {
  return (
    <>
      <HeroSlider />
      <ProductSection title="Starters" size="lg" products={getProductsIn("starters")} href="/category/starters" />
      <ProductSection title="Burgers" products={getProductsIn("burgers")} href="/category/burgers" />
      <VideoBanner />
      <div className="pt-4">
        <ProductSection title="Freshly baked, just for you" products={getProductsIn("pizza", "sandwich")} href="/category/deli" />
      </div>
    </>
  );
}
