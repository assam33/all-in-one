import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { allCategorySlugs, findCategory } from "@/data/categories";
import { getProductsIn } from "@/data/products";
import ProductGrid from "@/components/product/ProductGrid";

type Props = { params: Promise<{ slug: string }> };

export const dynamicParams = false;
export const generateStaticParams = () => allCategorySlugs.map((slug) => ({ slug }));

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const cat = findCategory((await params).slug);
  return { title: cat?.label ?? "Category" };
}

export default async function CategoryPage({ params }: Props) {
  const { slug } = await params;
  const cat = findCategory(slug);
  if (!cat) notFound();

  const items = getProductsIn(slug);
  const siblings = cat.children ?? cat.parent?.children;
  const chip = "rounded-full border px-4 py-1.5 text-sm transition-colors hover:border-brand hover:text-brand";

  return (
    <div className="mx-auto max-w-[1366px] px-4 pb-8">
      <h1 className="pb-8 pt-12 text-center text-3xl uppercase text-[orangered] md:text-4xl">{cat.label}</h1>

      {siblings && (
        <ul className="mb-10 flex flex-wrap justify-center gap-2">
          {cat.parent && (
            <li><Link href={`/category/${cat.parent.slug}`} className={`${chip} border-white/30`}>All {cat.parent.label}</Link></li>
          )}
          {siblings.map((k) => (
            <li key={k.slug}>
              <Link href={`/category/${k.slug}`} className={`${chip} ${k.slug === slug ? "border-brand bg-brand" : "border-white/30"}`}>{k.label}</Link>
            </li>
          ))}
        </ul>
      )}

      {items.length > 0 ? (
        <ProductGrid products={items} />
      ) : (
        <div className="py-20 text-center text-white/70">
          <p className="mb-6 text-lg">Items for this section are coming soon.</p>
          <Link href="/" className="rounded-md bg-brand px-6 py-2.5 font-bold text-white">BACK TO HOME</Link>
        </div>
      )}
    </div>
  );
}
