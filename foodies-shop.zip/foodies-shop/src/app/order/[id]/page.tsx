import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CheckCircle2 } from "lucide-react";
import { getOrder } from "@/lib/orders";
import { formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order status", robots: { index: false } };

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const order = await getOrder((await params).id);
  if (!order) notFound();

  return (
    <div className="mx-auto max-w-[700px] px-4 pb-8 pt-12">
      <div className="mb-8 text-center">
        <CheckCircle2 className="mx-auto mb-3 size-14 text-green-500" />
        <h1 className="text-3xl">Order received</h1>
        <p className="mt-2 text-white/70">Thank you, {order.customer.name}. We will contact you shortly to confirm.</p>
      </div>

      <div className="rounded-md bg-panel p-5">
        <div className="mb-4 flex flex-wrap justify-between gap-2 border-b border-white/10 pb-4 text-sm">
          <span>Order ID: <strong className="text-base">{order.id}</strong></span>
          <span className="text-white/70">{new Date(order.createdAt).toLocaleString("en-GB")}</span>
          <span className="rounded-full bg-brand px-3 text-xs uppercase leading-6">{order.status}</span>
        </div>
        <ul className="space-y-2 text-sm">
          {order.items.map((i) => (
            <li key={i.slug} className="flex justify-between"><span>{i.name} × {i.qty}</span><span>{formatPrice(i.price * i.qty)}</span></li>
          ))}
        </ul>
        <dl className="mt-4 space-y-1 border-t border-white/10 pt-4 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatPrice(order.subtotal)}</dd></div>
          <div className="flex justify-between"><dt>Delivery</dt><dd>{order.deliveryFee ? formatPrice(order.deliveryFee) : "Free"}</dd></div>
          <div className="flex justify-between text-lg"><dt>Total (Cash on delivery)</dt><dd>{formatPrice(order.total)}</dd></div>
        </dl>
      </div>

      <div className="mt-8 text-center">
        <Link href="/" className="rounded-md bg-brand px-6 py-2.5 font-bold">CONTINUE SHOPPING</Link>
      </div>
    </div>
  );
}
