import type { Metadata } from "next";
import CheckoutForm from "@/components/checkout/CheckoutForm";

export const metadata: Metadata = { title: "Checkout" };

export default function CheckoutPage() {
  return (
    <div className="mx-auto max-w-[1100px] px-4 pb-8">
      <h1 className="pb-8 pt-12 text-center text-3xl md:text-4xl">Checkout</h1>
      <CheckoutForm />
    </div>
  );
}
