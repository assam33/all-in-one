import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { findCategory } from "@/data/categories";
import { getProduct, getRelated, products } from "@/data/products";
import { formatPrice } from "@/lib/format";
import ProductActions from "@/components/product/ProductActions";
import ProductSection from "@/components/product/ProductSection";

type Props = { params: Promise<{ slug: string }> };

export const dynamicParams = false;
export const generateStaticParams = () => products.map((p) => ({ slug: p.slug }));

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = getProduct((await params).slug);
  return { title: p?.name ?? "Product", openGraph: p ? { images: [p.image] } : undefined };
}

export default async function ProductPage({ params }: Props) {
  const product = getProduct((await params).slug);
  if (!product) notFound();
  const category = findCategory(product.category);

  return (
    <>
      <div className="mx-auto grid max-w-[1100px] gap-8 px-4 py-12 md:grid-cols-2 md:gap-12">
        <div className="relative aspect-square w-full overflow-hidden">
          <Image src={product.image} alt={product.name} fill priority sizes="(min-width:768px) 50vw, 100vw" className="object-cover" />
        </div>
        <div className="flex flex-col justify-center gap-5">
          {category && (
            <Link href={`/category/${category.slug}`} className="text-sm uppercase text-[orangered] hover:underline">{category.label}</Link>
          )}
          <h1 className="text-3xl md:text-4xl">{product.name}</h1>
          <p className="text-2xl">{formatPrice(product.price)}</p>
          {product.description && <p className="text-white/70">{product.description}</p>}
          <ProductActions product={product} />
        </div>
      </div>
      <ProductSection title="You may also like" products={getRelated(product)} />
    </>
  );
}
