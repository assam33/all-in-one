export type Product = {
  slug: string; // unique id + URL segment
  name: string;
  price: number;
  image: string;
  category: string; // category slug
  description?: string;
};

export type CartLine = Pick<Product, "slug" | "name" | "price" | "image"> & { qty: number };

export type NavChild = { slug: string; label: string };
export type Category = { slug: string; label: string; children?: NavChild[] };

export type Order = {
  id: string;
  createdAt: string;
  status: "received";
  paymentMethod: "cod";
  customer: { name: string; phone: string; address: string; notes?: string };
  items: { slug: string; name: string; price: number; qty: number }[];
  subtotal: number;
  deliveryFee: number;
  total: number;
};
