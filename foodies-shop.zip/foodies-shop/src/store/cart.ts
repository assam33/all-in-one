"use client";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartLine, Product } from "@/types";

type CartState = {
  lines: CartLine[];
  add: (p: Product, qty?: number) => void;
  setQty: (slug: string, qty: number) => void;
  remove: (slug: string) => void;
  clear: () => void;
};

export const useCart = create<CartState>()(
  persist(
    (set) => ({
      lines: [],
      add: (p, qty = 1) =>
        set((s) => {
          const found = s.lines.find((l) => l.slug === p.slug);
          if (found) return { lines: s.lines.map((l) => (l.slug === p.slug ? { ...l, qty: l.qty + qty } : l)) };
          return { lines: [...s.lines, { slug: p.slug, name: p.name, price: p.price, image: p.image, qty }] };
        }),
      setQty: (slug, qty) =>
        set((s) => ({ lines: qty < 1 ? s.lines.filter((l) => l.slug !== slug) : s.lines.map((l) => (l.slug === slug ? { ...l, qty } : l)) })),
      remove: (slug) => set((s) => ({ lines: s.lines.filter((l) => l.slug !== slug) })),
      clear: () => set({ lines: [] }),
    }),
    { name: "foodies-cart" },
  ),
);

export const selectCount = (s: CartState) => s.lines.reduce((n, l) => n + l.qty, 0);
export const selectSubtotal = (s: CartState) => s.lines.reduce((n, l) => n + l.price * l.qty, 0);
