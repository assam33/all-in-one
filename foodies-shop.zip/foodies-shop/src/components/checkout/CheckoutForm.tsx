"use client";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { site } from "@/data/site";
import { formatPrice } from "@/lib/format";
import { orderSchema } from "@/lib/schemas";
import { selectSubtotal, useCart } from "@/store/cart";
import { useMounted } from "@/store/ui";

const input = "w-full rounded-md border border-white/20 bg-panel px-4 py-3 outline-none focus:border-brand";

export default function CheckoutForm() {
  const router = useRouter();
  const mounted = useMounted();
  const lines = useCart((s) => s.lines);
  const clear = useCart((s) => s.clear);
  const subtotal = useCart(selectSubtotal);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [busy, setBusy] = useState(false);

  if (!mounted) return <div className="min-h-[40vh]" />;
  if (lines.length === 0) {
    return (
      <div className="py-20 text-center">
        <p className="mb-6 text-lg text-white/70">Your cart is empty.</p>
        <Link href="/" className="rounded-md bg-brand px-6 py-2.5 font-bold">CONTINUE SHOPPING</Link>
      </div>
    );
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const get = (k: string) => String(fd.get(k) ?? "");
    const parsed = orderSchema.safeParse({
      customer: { name: get("name"), phone: get("phone"), address: get("address"), notes: get("notes") || undefined },
      items: lines.map((l) => ({ slug: l.slug, qty: l.qty })),
    });
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const i of parsed.error.issues) errs[String(i.path[1] ?? i.path[0])] ??= i.message;
      setErrors(errs);
      return;
    }
    setErrors({});
    setFormError("");
    setBusy(true);
    try {
      const res = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(parsed.data) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not place your order");
      router.push(`/order/${data.id}`);
      clear();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setBusy(false);
    }
  }

  const Field = ({ name, label, children }: { name: string; label: string; children: React.ReactNode }) => (
    <label className="block">
      <span className="mb-1.5 block text-sm">{label}</span>
      {children}
      {errors[name] && <span className="mt-1 block text-sm text-red-400">{errors[name]}</span>}
    </label>
  );

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_400px]">
      <form onSubmit={onSubmit} noValidate className="space-y-5">
        <Field name="name" label="Full name *"><input name="name" autoComplete="name" className={input} /></Field>
        <Field name="phone" label="Phone number *"><input name="phone" type="tel" autoComplete="tel" className={input} /></Field>
        <Field name="address" label="Delivery address *"><textarea name="address" rows={3} autoComplete="street-address" className={input} /></Field>
        <Field name="notes" label="Order notes (optional)"><textarea name="notes" rows={2} className={input} /></Field>
        <p className="rounded-md border border-white/20 bg-panel px-4 py-3 text-sm">Payment method: <strong>Cash on delivery</strong></p>
        {errors.items && <p className="text-red-400">{errors.items}</p>}
        {formError && <p className="text-red-400">{formError}</p>}
        <button disabled={busy} className="h-12 w-full rounded-md bg-brand font-bold disabled:opacity-60">{busy ? "PLACING ORDER..." : "PLACE ORDER"}</button>
      </form>

      <aside className="h-fit rounded-md bg-panel p-5">
        <h2 className="mb-4 text-xl">Order summary</h2>
        <ul className="space-y-3">
          {lines.map((l) => (
            <li key={l.slug} className="flex items-center gap-3 text-sm">
              <Image src={l.image} alt="" width={48} height={48} className="size-12 rounded-md object-cover" />
              <span className="flex-1">{l.name} × {l.qty}</span>
              <span>{formatPrice(l.price * l.qty)}</span>
            </li>
          ))}
        </ul>
        <dl className="mt-5 space-y-2 border-t border-white/20 pt-4 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatPrice(subtotal)}</dd></div>
          <div className="flex justify-between"><dt>Delivery</dt><dd>{site.deliveryFee ? formatPrice(site.deliveryFee) : "Free"}</dd></div>
          <div className="flex justify-between text-lg"><dt>Total</dt><dd>{formatPrice(subtotal + site.deliveryFee)}</dd></div>
        </dl>
      </aside>
    </div>
  );
}
