"use client";
import Image from "next/image";
import Link from "next/link";
import { Minus, Plus } from "lucide-react";
import { formatPrice } from "@/lib/format";
import { selectSubtotal, useCart } from "@/store/cart";
import { useMounted, useUI } from "@/store/ui";
import Drawer from "@/components/ui/Drawer";

export default function CartDrawer() {
  const mounted = useMounted();
  const { cartOpen, set } = useUI();
  const { lines, setQty, remove, clear } = useCart();
  const subtotal = useCart(selectSubtotal);
  const close = () => set({ cartOpen: false });
  const items = mounted ? lines : [];
  const qtyBtn = "grid size-7 place-items-center hover:text-brand";

  return (
    <Drawer open={cartOpen} onClose={close} title="CART ITEMS" className="bg-[#a35555]">
      {items.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center">
          <p>Your cart is empty.</p>
          <Link href="/category/deli" onClick={close} className="rounded-md bg-brand px-6 py-2.5 font-bold">BROWSE MENU</Link>
        </div>
      ) : (
        <>
          <ul className="flex-1 space-y-4 overflow-y-auto p-4">
            {items.map((l) => (
              <li key={l.slug} className="flex items-center gap-3">
                <Image src={l.image} alt="" width={50} height={50} className="size-[50px] shrink-0 rounded-full object-cover" />
                <div className="min-w-0 flex-1">
                  <Link href={`/product/${l.slug}`} onClick={close} className="line-clamp-2 text-sm font-bold">{l.name}</Link>
                  <p className="text-sm">{formatPrice(l.price)}</p>
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  <div className="flex items-center bg-maroon">
                    <button aria-label="Decrease quantity" onClick={() => setQty(l.slug, l.qty - 1)} className={qtyBtn}><Minus className="size-4" /></button>
                    <span className="w-6 text-center">{l.qty}</span>
                    <button aria-label="Increase quantity" onClick={() => setQty(l.slug, l.qty + 1)} className={qtyBtn}><Plus className="size-4" /></button>
                  </div>
                  <button onClick={() => remove(l.slug)} className="bg-brand px-3 py-0.5 text-sm font-bold">Del</button>
                </div>
              </li>
            ))}
          </ul>
          <div className="space-y-3 border-t-[3px] border-black p-4">
            <div className="flex justify-between text-lg"><span>Total:</span><span>{formatPrice(subtotal)}</span></div>
            <Link href="/checkout" onClick={close} className="block rounded-md bg-brand py-3 text-center font-bold">CHECKOUT</Link>
            <button onClick={clear} className="w-full text-sm underline">Clear cart</button>
          </div>
        </>
      )}
    </Drawer>
  );
}
