"use client";
import Image from "next/image";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/pagination";

const slides = [
  "/images/hero/company.webp",
  "/images/hero/poster-1.webp",
  "/images/hero/poster-3.webp",
  "/images/hero/hero-1.jpg",
  "/images/hero/hero-2.webp",
  "/images/hero/hero-3.avif",
  "/images/hero/hero-4.webp",
];

export default function HeroSlider() {
  return (
    <section aria-label="Promotions">
      <Swiper
        modules={[Autoplay, Pagination]}
        autoplay={{ delay: 3000, disableOnInteraction: false }}
        pagination={{ clickable: true }}
        loop
        style={{ "--swiper-theme-color": "#ff0000" } as React.CSSProperties}
        className="h-[220px] sm:h-[380px] lg:h-[568px]"
      >
        {slides.map((src, i) => (
          <SwiperSlide key={src}>
            <Image src={src} alt={`Promotion ${i + 1}`} fill sizes="100vw" priority={i === 0} className="object-cover" />
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
}
