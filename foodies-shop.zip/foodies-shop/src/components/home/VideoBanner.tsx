import { site } from "@/data/site";

export default function VideoBanner() {
  return (
    <section className="bg-panel py-8 md:py-0">
      <div className="mx-auto flex max-w-[1366px] flex-col-reverse md:h-[476px] md:flex-row">
        <div className="w-full md:w-1/2 md:pl-[85px]">
          <video
            src="/videos/pizza.mp4"
            autoPlay loop muted playsInline preload="metadata"
            className="h-[150px] w-full object-scale-down md:h-[476px]"
          />
        </div>
        <div className="flex w-full flex-col items-center px-4 pb-10 text-center md:w-1/2 md:items-start md:pb-0 md:pl-[50px] md:pt-[100px] md:text-left">
          <h2 className="text-[25px] leading-tight md:text-[54px]">Delicious Slices, Crafted With Passion!</h2>
          <p className="mt-5 text-sm leading-6">
            Indulge in the perfect blend of cheesy goodness and mouth-watering toppings with {site.company}&apos; irresistible pizzas.
          </p>
        </div>
      </div>
    </section>
  );
}
