import Image from "next/image";
import Link from "next/link";
import type { Product } from "@/types";
import { formatPrice } from "@/lib/format";
import AddToCartButton from "./AddToCartButton";

export default function ProductCard({ product }: { product: Product }) {
  return (
    <article className="flex flex-col gap-5">
      <Link href={`/product/${product.slug}`} className="group block">
        <div className="relative aspect-[285/269] w-full overflow-hidden">
          <Image
            src={product.image}
            alt={product.name}
            fill
            sizes="(min-width:1024px) 25vw, (min-width:768px) 33vw, 50vw"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
        <div className="mt-3 flex min-h-[60px] flex-col justify-end gap-2 text-center text-sm font-bold">
          <p>{product.name}</p>
          <p>{formatPrice(product.price)}</p>
        </div>
      </Link>
      <AddToCartButton product={product} />
    </article>
  );
}
