"use client";
import type { Product } from "@/types";
import { useCart } from "@/store/cart";
import { useUI } from "@/store/ui";

export default function AddToCartButton({ product, qty = 1 }: { product: Product; qty?: number }) {
  const add = useCart((s) => s.add);
  const set = useUI((s) => s.set);
  return (
    <button
      onClick={() => { add(product, qty); set({ cartOpen: true }); }}
      className="h-11 w-full rounded-[5px] bg-brand text-sm font-bold transition-colors hover:bg-red-700"
    >
      ADD TO CART
    </button>
  );
}
