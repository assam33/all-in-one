"use client";
import { useState } from "react";
import { Minus, Plus } from "lucide-react";
import type { Product } from "@/types";
import AddToCartButton from "./AddToCartButton";

export default function ProductActions({ product }: { product: Product }) {
  const [qty, setQty] = useState(1);
  const btn = "grid size-10 place-items-center hover:text-brand";
  return (
    <div className="flex flex-wrap items-center gap-4">
      <div className="flex items-center border border-white/20">
        <button aria-label="Decrease quantity" onClick={() => setQty((q) => Math.max(1, q - 1))} className={btn}><Minus className="size-4" /></button>
        <span className="w-10 text-center">{qty}</span>
        <button aria-label="Increase quantity" onClick={() => setQty((q) => Math.min(50, q + 1))} className={btn}><Plus className="size-4" /></button>
      </div>
      <div className="min-w-[200px] flex-1"><AddToCartButton product={product} qty={qty} /></div>
    </div>
  );
}
