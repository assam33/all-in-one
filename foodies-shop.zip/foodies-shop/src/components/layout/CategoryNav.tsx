import Link from "next/link";
import { ChevronDown } from "lucide-react";
import { categories } from "@/data/categories";

export default function CategoryNav() {
  return (
    <nav aria-label="Categories" className="hidden h-[45px] border-y border-white/20 md:block">
      <ul className="mx-auto flex h-full max-w-[1366px] items-center justify-center gap-6 px-4 lg:gap-[50px] xl:gap-[70px]">
        {categories.map((c) => {
          const half = Math.ceil((c.children?.length ?? 0) / 2);
          const cols = c.children ? [c.children.slice(0, half), c.children.slice(half)] : [];
          return (
            <li key={c.slug} className="group relative flex h-full items-center">
              <Link href={`/category/${c.slug}`} className="flex items-center gap-1 text-xs uppercase hover:text-brand group-hover:text-brand">
                {c.label}
                {c.children && <ChevronDown className="size-4 rotate-90 transition-transform group-hover:rotate-0 group-focus-within:rotate-0" />}
              </Link>
              {c.children && (
                <div className="invisible absolute left-0 top-full z-50 grid w-[480px] grid-cols-2 bg-ink opacity-0 shadow-lg shadow-black/50 group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                  {cols.map((col, i) => (
                    <ul key={i} className="py-2">
                      {col.map((k) => (
                        <li key={k.slug}>
                          <Link href={`/category/${k.slug}`} className="block py-2 pl-6 text-sm hover:bg-brand">{k.label}</Link>
                        </li>
                      ))}
                    </ul>
                  ))}
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
