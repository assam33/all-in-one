import type { Product } from "@/types";
import { categorySlugs } from "./categories";

// To add a product: add one object here (and its image in /public/images/products).
// Later this file can be replaced by a database/CMS query without touching components.
export const products: Product[] = [
  // Starters (Pan Asian)
  { slug: "the-famous-soup", name: "The Famous Soup", price: 600, image: "/images/products/soup-1.webp", category: "starters" },
  { slug: "szechuan-soup", name: "Szechuan Soup (Single Serving)", price: 499, image: "/images/products/soup-2.webp", category: "starters" },
  { slug: "hot-and-sour-soup", name: "Hot & Sour Soup (Single Serving)", price: 499, image: "/images/products/soup-3.webp", category: "starters" },
  { slug: "chicken-corn-soup", name: "Chicken Corn Soup (Single Serving)", price: 499, image: "/images/products/soup-4.webp", category: "starters" },
  // Burgers (Deli)
  { slug: "crispy-chicken-burger", name: "Crispy Chicken Burger", price: 450, image: "/images/products/burger-1.webp", category: "burgers" },
  { slug: "peri-peri-chicken-burger", name: "Peri Peri Chicken Burger", price: 799, image: "/images/products/burger-2.webp", category: "burgers" },
  { slug: "hot-chick-burger", name: "Hot Chick Burger", price: 599, image: "/images/products/burger-3.webp", category: "burgers" },
  { slug: "double-beef-cheese-burger", name: "Double Beef Cheese Burger", price: 899, image: "/images/products/burger-4.webp", category: "burgers" },
  // Pizza & Sandwich (Deli)
  { slug: "peri-peri-pizza-l", name: "Peri Peri Pizza (L)", price: 2200, image: "/images/products/pizza-1.webp", category: "pizza" },
  { slug: "supreme-beef-pizza-l", name: "Supreme Beef Pizza (L)", price: 2200, image: "/images/products/pizza-2.webp", category: "pizza" },
  { slug: "fajita-sandwich", name: "Fajita Sandwich", price: 599, image: "/images/products/sandwich-1.webp", category: "sandwich" },
  { slug: "bbq-sandwich", name: "BBQ Sandwich", price: 599, image: "/images/products/sandwich-2.webp", category: "sandwich" },
  // SAMPLE DATA - the original site only had placeholder bakery items. Replace with real ones.
  { slug: "fresh-bread", name: "Fresh Bread", price: 350, image: "/images/products/bakery-1.avif", category: "bread" },
  { slug: "butter-croissant", name: "Butter Croissant", price: 400, image: "/images/products/bakery-1.avif", category: "pastries" },
  { slug: "belgian-waffle", name: "Belgian Waffle", price: 550, image: "/images/products/bakery-1.avif", category: "pastries" },
];

export const getProduct = (slug: string) => products.find((p) => p.slug === slug);

export const getProductsIn = (...cats: string[]) => {
  const set = new Set(cats.flatMap(categorySlugs));
  return products.filter((p) => set.has(p.category));
};

export const searchProducts = (q: string) => {
  const term = q.trim().toLowerCase();
  return term ? products.filter((p) => p.name.toLowerCase().includes(term)) : [];
};

export const getRelated = (p: Product, limit = 4) =>
  products.filter((x) => x.category === p.category && x.slug !== p.slug).slice(0, limit);
