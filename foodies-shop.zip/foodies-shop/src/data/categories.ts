import type { Category, NavChild } from "@/types";
import { slugify } from "@/lib/format";

const kids = (labels: string[]): NavChild[] => labels.map((label) => ({ label, slug: slugify(label) }));
const top = (label: string, children?: string[]): Category => ({
  label,
  slug: slugify(label),
  children: children && kids(children),
});

export const categories: Category[] = [
  top("Bakery", ["Bread", "Brownies", "Cakes", "Customise Icecream", "Donuts & Cupcake", "Pastries", "Rusk", "Salad", "Buns", "Biscuits & Khatai", "Cake Rusk", "Confectionery", "JI Dairy", "Puff Pastries", "Salted Snacks"]),
  top("Deli", ["Burgers", "Deli Fish", "JI New Arrivals", "Peri Peri Chicken", "Crispy Fried Chicken", "Italian Cuisine", "Pizza", "Sandwich"]),
  top("Pan Asian", ["Classic Entree", "Premium Entree", "Starters", "Chow Main", "Premium Entree (Seafood)"]),
  top("JI Icecream"),
  top("Drinks"),
  top("Eatables"),
  top("Special"),
  top("Deals"),
  top("Others"),
];

export type CategoryMatch = { slug: string; label: string; parent?: Category; children?: NavChild[] };

export function findCategory(slug: string): CategoryMatch | undefined {
  for (const c of categories) {
    if (c.slug === slug) return { slug: c.slug, label: c.label, children: c.children };
    const child = c.children?.find((k) => k.slug === slug);
    if (child) return { ...child, parent: c };
  }
}

/** A parent category includes all of its children's products. */
export const categorySlugs = (slug: string): string[] => {
  const c = categories.find((x) => x.slug === slug);
  return c ? [c.slug, ...(c.children?.map((k) => k.slug) ?? [])] : [slug];
};

export const allCategorySlugs = categories.flatMap((c) => [c.slug, ...(c.children?.map((k) => k.slug) ?? [])]);
