import { z } from "zod";

// Shared by the checkout form (client) and the orders API (server).
export const customerSchema = z.object({
  name: z.string().trim().min(2, "Please enter your full name"),
  phone: z.string().trim().regex(/^\+?[\d\s-]{7,16}$/, "Enter a valid phone number"),
  address: z.string().trim().min(8, "Please enter your complete delivery address"),
  notes: z.string().trim().max(500, "Notes are too long").optional(),
});

export const orderSchema = z.object({
  customer: customerSchema,
  items: z.array(z.object({ slug: z.string(), qty: z.number().int().min(1).max(50) })).min(1, "Your cart is empty"),
});

export type OrderInput = z.infer<typeof orderSchema>;
