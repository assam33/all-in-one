import "server-only";
import { randomBytes } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import type { Order } from "@/types";
import type { OrderInput } from "./schemas";
import { getProduct } from "@/data/products";
import { site } from "@/data/site";

/**
 * File-based order storage so the shop works out of the box.
 * For production swap these two functions for a database (Prisma/Postgres, Supabase...).
 * Note: serverless hosts (e.g. Vercel) have a read-only filesystem, so a DB is required there.
 */
const file = path.resolve(/*turbopackIgnore: true*/ process.env.ORDERS_FILE ?? ".data/orders.json");

async function readAll(): Promise<Order[]> {
  try {
    return JSON.parse(await readFile(file, "utf8"));
  } catch {
    return [];
  }
}

export async function getOrder(id: string) {
  return (await readAll()).find((o) => o.id === id.toUpperCase());
}

export async function createOrder(input: OrderInput): Promise<Order> {
  // Prices always come from the server catalogue, never from the browser.
  const items = input.items.map(({ slug, qty }) => {
    const p = getProduct(slug);
    if (!p) throw new Error(`Unknown product: ${slug}`);
    return { slug, name: p.name, price: p.price, qty };
  });
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const order: Order = {
    id: `JI-${randomBytes(4).toString("hex").toUpperCase()}`,
    createdAt: new Date().toISOString(),
    status: "received",
    paymentMethod: "cod",
    customer: input.customer,
    items,
    subtotal,
    deliveryFee: site.deliveryFee,
    total: subtotal + site.deliveryFee,
  };
  const all = await readAll();
  await mkdir(path.dirname(file), { recursive: true });
  await writeFile(file, JSON.stringify([...all, order], null, 2));
  return order;
}
